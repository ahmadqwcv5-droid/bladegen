# FP02-C1 contract and operation table

This table records the engineering interpretation used to select the bounded
validator correction. No BladeSpec values, native runtime behavior, tolerances,
station plans, cap settings, or STEP export settings were changed.

| Concern | Contract/input authority | Native generation behavior | Legacy expected calculation | Corrected independent calculation |
| --- | --- | --- | --- | --- |
| Airfoil interpolation | Explicit airfoil stations; linear profile interpolation in normalized section space | Blends adjacent profiles by radial fraction | Same blend | Same blend |
| Thickness curve | Independent BladeSpec Thickness distribution and its declared Linear/PCHIP interpolation | Applies the Thickness curve after profile blending | Used only endpoint/control thickness while blending; intermediate PCHIP value was omitted | Evaluates the independent curve at the sampled station and scales chord-normal half-thickness about the camber line by `target_ratio / blended_profile_ratio` |
| NACA thickness | NACA profile plus the independent Thickness control | Control profiles reflect local thickness | Correct at explicit stations | Unchanged at explicit stations; identity when target and blended ratios agree |
| Imported coordinates | Coordinates are authoritative unless a compatible Thickness curve is supplied | Uses imported shape and compatible Thickness controls | Existing explicit-profile calculation | Unchanged; Q04.R1 uses the profile's full-precision natural ratio at the existing controls |
| Finite trailing edge | Physical TE millimetres at explicit airfoil stations | TE is applied to control profiles before profile blending; subsequent Thickness scaling affects its half-gap | Blended control-profile TE but omitted the later Thickness scaling | TE is inherited from the corrected full contour after the same post-blend Thickness scale; no new TE law |
| Chord and TE conversion | Chord from the declared curve; physical TE divided by local chord while constructing the normalized control profile | Native output preserves requested dimensional intent within existing tolerances | Correct at controls, wrong at affected intermediates because of the omitted scale | Uses unchanged chord evaluation and obtains physical TE from the corrected normalized contour times chord |
| Reverse direction | Existing product contract; same BladeSpec curves with the native geometry reflected tangentially | OpenVSP reflects global section Z for Reverse | Expected frame and twist extraction assumed Normal | Reflects expected reference/chord/normal vectors in global tangential Z and measures Reverse twist as `90 + atan2(z, x)` |

At Q02/Q03 `r/R=0.30`, the blended endpoint thickness was 0.135 while the
declared PCHIP target was 0.129375, giving scale 0.9583333333333331. At
`r/R=0.35`, those values were 0.1275 and 0.122578125, giving scale
0.9613970588235292. At passing controls such as 0.40 and 0.50 the scale is one,
which explains why those sections were unaffected.

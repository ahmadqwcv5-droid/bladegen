// Isolated reproduction of the published App.tsx commit callback and Cancel callback.
// This is NOT a mounted React test. State setters and validation transport are recording fakes.
const fs=require('fs'),path=require('path');
let spec={name:'before',chord_distribution:{points:[{r_over_R:.2,chord_over_R:.3},{r_over_R:1,chord_over_R:.1}]}};
const candidate=structuredClone(spec);candidate.chord_distribution.points[0].chord_over_R=.32;
const specRef={current:spec},curveValidationRevision={current:0};
let curveInteraction='idle',dialog={open:true},errors=[],message='';
const history=[];const curveHistory={push:x=>history.push(x)};
const canonicalJson=JSON.stringify;
const validateEditorSpec=()=>[];
let completeValidation; const validation=new Promise(resolve=>completeValidation=resolve);
const validateBackend=()=>validation;
const setErrors=x=>errors=x, setMessage=x=>message=x, setCurveInteraction=x=>curveInteraction=x;
const refreshHistory=()=>{},markDraftModified=()=>{};
const setSpec=x=>{spec=x;specRef.current=x};
const setDistributionImportSnapshot=x=>dialog=x;
// TypeScript annotations removed; executable control flow below matches the repository callback.
const commitCurveCandidate=async(candidate,label,expectedSnapshot)=>{
 const before=specRef.current;
 if(!before||curveInteraction==='validating')return false;
 const beforeSnapshot=canonicalJson(before);
 if(expectedSnapshot&&beforeSnapshot!==expectedSnapshot){setErrors(['The design changed after this review opened. Reopen the operation to review values against the current snapshot.']);setMessage(`${label} cancelled because the design changed`);return false;}
 if(canonicalJson(candidate)===beforeSnapshot)return true;
 const local=validateEditorSpec(candidate);
 if(local.length){setErrors(local);setMessage(`Curve edit rejected: ${local[0]}`);setCurveInteraction('idle');return false;}
 const token=++curveValidationRevision.current;
 setCurveInteraction('validating');setErrors([]);setMessage(`Validating ${label}…`);
 try{
  await validateBackend(candidate);
  if(curveValidationRevision.current!==token||!specRef.current||canonicalJson(specRef.current)!==beforeSnapshot)return false;
  curveHistory.push({before,after:candidate,label});refreshHistory();markDraftModified();setSpec(structuredClone(candidate));setErrors([]);setMessage(`${label} committed; canonical preview updating`);return true;
 }catch(error){
  if(curveValidationRevision.current!==token)return false;
  const detail=error instanceof Error?error.message:String(error);setErrors([`Curve edit rejected by backend: ${detail}`]);setMessage(`Curve edit rejected: ${detail}`);return false;
 }finally{if(curveValidationRevision.current===token)setCurveInteraction('idle');}
};
(async()=>{
 const pending=commitCurveCandidate(candidate,'Import Chord',canonicalJson(spec));
 // Published DistributionImportDialog onCancel in App.tsx:
 setDistributionImportSnapshot(undefined);
 completeValidation({valid:true});
 const accepted=await pending;
 const result={scope:'Isolated published callback control flow with recording state/transport fakes; not React/Playwright execution',sequence:'Apply -> validation pending -> Cancel closes dialog -> validation succeeds',dialogClosed:dialog===undefined,accepted,committedChordOverR:spec.chord_distribution.points[0].chord_over_R,historyEntries:history.length,requirement:'Cancel must prevent pending candidate commit',requirementPassed:!accepted&&history.length===0};
 fs.writeFileSync(path.join(__dirname,'results/cancel_probe.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
})();

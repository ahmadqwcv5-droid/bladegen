# دليل تشغيل تجربة BladeGen Level 1

## الحالة الحالية

**التجربة الرسمية للمستخدم مؤجلة حالياً (`FP02_BLOCKED`).** نجح مسارا المتصفح U1 وU2، ونجح نموذج X-57 داخلياً، لكن مصفوفة القبول الإلزامية نجحت في 5 حالات فقط من أصل 8: فشلت Q02 وQ03 في فحص هندسة المقاطع، ورُفضت Q04 قبل التوليد بسبب تعارض السماكة. لا تعتبر هذه النسخة إصداراً مؤهلاً حتى تُغلق هذه الحالات ويُعاد الاختبار.

هذا الدليل يحتفظ بخطوات التشغيل الدقيقة للاستخدام بعد قرار إغلاق العوائق أو لإعادة الفحص التشخيصي المنضبط. قبولك الشخصي ما زال `PENDING`.

## بدء وإيقاف البرنامج

من مجلد المستودع `bladegen` شغّل:

```bash
./scripts/start_level1_trial.sh
```

يجب أن ترى:

- `BladeGen profile: level1-trial`
- `Worker timeout: 900 seconds per design`
- `Generation runtime: READY`
- الواجهة: `http://127.0.0.1:5175`
- الخلفية: `http://127.0.0.1:8012`

افتح `http://127.0.0.1:5175` في المتصفح. للإيقاف اضغط `Ctrl+C` مرة واحدة في الطرفية؛ السكربت يوقف فقط عمليتي الخلفية والواجهة اللتين بدأهما.

الحد 900 ثانية هو حد أقصى لكل عملية توليد في ملف التشغيل `level1-trial`. الإعداد العادي ما زال 300 ثانية. لا تحتاج إلى إعادة بناء OpenVSP أو تعديل Python/C++ أو ضبط متغيرات مخفية.

## ملفات التجربة

- مجلد الإدخالات: `qualification/fp02/trial_inputs/`
- الحزمة: `qualification/fp02/FP02_LEVEL1_TRIAL_INPUTS.zip`
- الشفرة البسيطة: `trial_inputs/simple/FP02_Q01_simple_blade.json`
- CSV البسيط: `trial_inputs/simple/FP02_Q01_distributions.csv`
- تعديل الالتواء: `trial_inputs/simple/FP02_Q01_twist_edit.json`
- المروحة الثنائية: `trial_inputs/simple/FP02_Q06_two_blade_propeller.json`
- ملف X-57 الهوائي: `trial_inputs/x57/x57_hlp_airfoil.csv`
- توزيعات X-57 الفيزيائية: `trial_inputs/x57/x57_hlp_control_points_mm.csv`
- فحوص X-57: `trial_inputs/x57/SHA256SUMS.txt`

للتحقق من ملفات X-57:

```bash
cd qualification/fp02/trial_inputs/x57
sha256sum --check SHA256SUMS.txt
```

يجب أن تكون كل النتائج `OK`.

## 1. إنشاء الشفرة البسيطة ثم تعديلها

1. اضغط `New` واختر `Single Blade`.
2. أدخل `Name` = `FP02_Q01_simple_three_station`، و`Diameter` = `400`، و`Root radius` = `0.25`، و`Reference axis` = `0.25`، و`Rotation` = `Normal`.
3. اضغط `Set Up Airfoil Stations`، واجعل `Total airfoil stations` = `3` و`Common station trailing edge` = `0`، ثم اضغط `Apply Once`.
4. حدد المحطات الثلاث، واضغط `Apply Profile to Selected Stations`، واختر `NACA 0012`، وفعّل `Use constant thickness for selected common profile`، ثم اضغط `Apply to 3 Selected Stations`.
5. اضغط `Import Distributions` واختر `FP02_Q01_distributions.csv`. تحقق من ظهور `3 rows`، واجعل Interpolation لكل من Chord/Twist/Rake/Skew/Thickness هو `Linear`، ثم اضغط `Apply Once`.
6. انتظر رسالة `Canonical design preview is current`. هذه الخطوة لا يجب أن تبدأ CAD تلقائياً.
7. اضغط `Generate Blade`. النتيجة المتوقعة: `Build complete` وروابط تخص Job الحالي: `blade_solid.step` و`blade_spec.json` و`validation.json` و`engine_manifest.json`.
8. اضغط `Export JSON` واحفظ المشروع. افتح الملف من حقل فتح JSON وتأكد من رسالة `Opened and validated` ومن بقاء القيم نفسها.
9. غيّر `Twist value 2` من `18` إلى `21`. يجب أن تظهر `Inputs changed — regenerate` و`Last successful build — previous inputs` من دون توليد تلقائي.
10. اضغط `Generate Blade` مرة ثانية. يجب أن يكون Job ID جديداً، وأن ينجح `validation.json`، وأن يقيس المقطع عند `r/R = 0.625` قرابة 21° بدلاً من 18°.

مرجع آلي ناجح: Job أول `45f79b86e57e410f9af8e19c37bf8daf`، وإعادة التوليد `1dc14de8d0424afea21772247dceb806`.

## 2. استيراد X-57 دفعة واحدة وتوليد الشفرة

1. ابدأ مشروعاً نظيفاً واختر `Single Blade`.
2. أدخل الاسم `X57_HLP_manual_test`، القطر `575.9200184294399` mm، `Root radius` = `0.20238`، `Reference axis` = `0.5`، و`Rotation` = `Normal`.
3. اضغط `Set Up Airfoil Stations`، واجعل العدد `2` وسمك الحافة الخلفية المشترك `0`، ثم `Apply Once`. لا تفعل خيارات الاستبدال أو الحفظ الإضافية.
4. حدد المحطتين واضغط `Apply Profile to Selected Stations`.
5. في `Airfoil coordinate file` اختر `x57_hlp_airfoil.csv`. اترك خيار `Explicitly normalize using LE and mean TE chord` غير مفعّل، واضغط `Import and Preview`، ثم فعّل السماكة الثابتة واضغط `Apply to 2 Selected Stations`.
6. اضغط `Import Distributions` واختر `x57_hlp_control_points_mm.csv`. تحقق من `40 rows` ومن Diameter snapshot `575.9200184294399 mm`، وأن Interpolation هو `PCHIP` لكل Chord/Twist/Rake/Skew، ثم `Apply Once` مرة واحدة.
7. انتظر `Canonical design preview is current`. Apply يجب أن يحدّث المعاينة فقط ولا يولد CAD.
8. اضغط `Export JSON` واحتفظ بالمرشح، ثم اضغط `Generate Blade` مرة واحدة.
9. النتيجة المتوقعة في البيئة المقاسة: 41/41 محطة، Solid واحد، Shell واحدة مغلقة، صفر free edges، وBRep valid. العملية المرجعية استغرقت 369.7 ثانية ضمن حد 900 ثانية.
10. نزّل ملفات Job نفسه: `blade_solid.step` و`blade_spec.json` و`validation.json` و`engine_manifest.json`.

الـ STEP المرجعي لهذه الجولة موجود في `qualification/fp02/x57_hlp_internal_validation_pass.step`، وSHA-256 له:

`06469e570930ddf41442b9a9d5b98ec9fd2f7ef5fee633676a3b219857604efd`

هذا نجاح داخلي لإدخالات وهندسة CAD، وليس إثبات مطابقة سطح خارجي رسمي من NASA؛ المطابقة الخارجية ما زالت `UNVERIFIED`.

## 3. إنشاء مروحة بسيطة مدعومة

هذه تجربة مروحة ثنائية بسيطة، وليست إعادة إنتاج لمروحة NASA ذات خمس شفرات.

1. افتح `FP02_Q06_two_blade_propeller.json` من حقل JSON.
2. تحقق من تفعيل `Full Propeller` ومن `Number of Blades` = `2`.
3. القيم المجمدة هي Hub قطره 90 mm وطوله 45 mm وثقب Shaft قطره 12 mm.
4. اضغط `Generate Propeller`.
5. النتيجة المتوقعة: `Build complete`، شفرتان مطلوبتان وشفرتان موضوعتان، Solid واحد مغلق وBRep valid بعد إعادة استيراد STEP.

مرجع آلي ناجح: Job `654cecad2ec3430686470ae66d62e4c3`، زمن العامل 97.3 ثانية.

## عند حدوث مشكلة

- لا ترفع الحد فوق 900 ثانية ولا تغيّر السماحات أو بيانات X-57 للحصول على PASS.
- احتفظ بـ Job ID ورسالة الخطأ و`validation.json` و`engine_manifest.json` وملفات stdout/stderr.
- إذا فشل Job جديد، فالمعاينة القديمة يجب أن تبقى معنونة كـ `previous` أو `stale` ولا تعتبر نتيجة للعملية الفاشلة.
- بعد أي تغيير في كود/Runtime، أعد تشغيل `./scripts/start_level1_trial.sh` حتى يعيد فحص Runtime قبل التوليد.
- التقرير الكامل: `docs/FP02_REPORT.md`. مصفوفة القبول: `docs/FP02_ACCEPTANCE_MATRIX.md`.

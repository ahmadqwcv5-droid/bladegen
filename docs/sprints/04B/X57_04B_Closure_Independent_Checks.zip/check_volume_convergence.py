"""Read-only numerical volume diagnostic; not a CAD acceptance test."""
from pathlib import Path
import time,json
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
r=STEPControl_Reader();assert r.ReadFile('/mnt/data/blade_solid.step')==IFSelect_RetDone
r.TransferRoots();s=r.OneShape();rows=[]
for eps in (1e-8,1e-9,1e-10):
    p=GProp_GProps();t=time.monotonic()
    err=BRepGProp.VolumePropertiesGK_s(s,p,eps,True,True,False,False,False)
    rows.append({'requested_eps':eps,'volume_mm3':p.Mass(),'returned_error_estimate':err,'seconds':time.monotonic()-t})
    print(rows[-1],flush=True)
fixed=GProp_GProps();BRepGProp.VolumeProperties_s(s,fixed)
obj={'scope':'Volume diagnostic only; does not test section fidelity or external NASA geometry','adaptive_runs':rows,'fixed_rule_volume_mm3':fixed.Mass(),'adaptive_volume_range_mm3':max(v['volume_mm3'] for v in rows)-min(v['volume_mm3'] for v in rows),'fixed_minus_eps1e9_mm3':fixed.Mass()-rows[1]['volume_mm3'],'fixed_difference_percent_of_eps1e9':100*(fixed.Mass()-rows[1]['volume_mm3'])/rows[1]['volume_mm3']}
Path('/mnt/data/review_04b_closure/volume_convergence.json').write_text(json.dumps(obj,indent=2))
print(json.dumps(obj,indent=2),flush=True)

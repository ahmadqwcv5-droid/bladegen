from pathlib import Path
import sys,json,importlib.util,hashlib,zipfile
from types import SimpleNamespace
import numpy as np
from scipy.interpolate import PchipInterpolator
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source/backend'))
spec=importlib.util.spec_from_file_location('audit_canonical',root/'source/backend/canonical.py'); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
results=[]
def test(name,fn):
 try: value=fn();results.append({'name':name,'status':'PASS','details':value})
 except Exception as exc: results.append({'name':name,'status':'FAIL','error':str(exc)})
def curve(x,y,mode='pchip'):
 return SimpleNamespace(interpolation=mode,points=[SimpleNamespace(r_over_R=float(a),twist_deg=float(b)) for a,b in zip(x,y)])
def dense(mode):
 rng=np.random.default_rng(5704); largest=0; cases=0
 for n in (2,5,40,200):
  for _ in range(5):
   x=np.r_[.20238,np.sort(rng.uniform(.20239,.99999,n-2)),1.];y=rng.normal(0,50,n)
   c=curve(x,y,mode);e=module.prepare_curve(c,'twist_deg')
   q=np.r_[x,np.linspace(x[0],1,5001),rng.uniform(x[0],1,37),np.nextafter(x[1:-1],-np.inf),np.nextafter(x[1:-1],np.inf)]
   expected=np.interp(q,x,y) if mode=='linear' else PchipInterpolator(x,y,extrapolate=False)(q)
   for k,a in enumerate(x): expected[q==a]=y[k]
   actual=e.evaluate_many(q);np.testing.assert_array_equal(e.evaluate_many(x),y)
   np.testing.assert_allclose(actual,expected,rtol=0,atol=1e-12)
   largest=max(largest,float(np.max(np.abs(actual-expected))));cases+=1
 return {'curves':cases,'largest_difference':largest,'dense_locations_per_curve':5001}
test('PCHIP same knots near-knots and dense values as direct SciPy',lambda:dense('pchip'))
test('Linear same knots near-knots and dense values as numpy',lambda:dense('linear'))
from bladegen.models.blade_spec import BladeSpec
candidate=json.loads((root/'results/x57_candidate_HELPER_ONLY.json').read_text())
b=BladeSpec.model_validate(candidate)
for key,field in [('chord_distribution','chord_over_R'),('twist_distribution','twist_deg'),('rake_distribution','rake_over_R'),('skew_distribution','skew_over_R')]:
 def fn(k=key,f=field):
  c=getattr(b,k);e=module.prepare_curve(c,f);x,y=module.curve_data(c,f);q=np.linspace(x[0],x[-1],5001);r=PchipInterpolator(x,y,extrapolate=False)(q)
  for i,a in enumerate(x):r[q==a]=y[i]
  np.testing.assert_array_equal(e.evaluate_many(q),r)
  return {'points':len(x),'queries':len(q),'maximum_difference':0}
 test('Actual X57 helper-import '+key,fn)
c=curve([.2,.6,1],[10,-4,15]);e=module.prepare_curve(c,'twist_deg')
def expect_reject(q):
 try:e.evaluate_many(q)
 except ValueError:return 'rejected'
 raise AssertionError('Accepted invalid queries')
for name,q in [('below root',[.19]),('above tip',[1.001]),('nan',[float('nan')]),('infinity',[float('inf')])]:test('domain/finite check '+name,lambda q=q:expect_reject(q))
def constructors():
 calls=[];old=module.PchipInterpolator
 def wrapper(*a,**kw): calls.append(1);return old(*a,**kw)
 module.PchipInterpolator=wrapper
 try:
  e=module.prepare_curve(c,'twist_deg');e.evaluate_many(np.linspace(.2,1,5001));[e.evaluate(q) for q in [.2,.3,.6,.9,1]]
  assert len(calls)==1
 finally:module.PchipInterpolator=old
 return {'constructors':len(calls),'dense_queries':5001,'additional_scalar_queries':5}
test('one PCHIP object reused',constructors)
report={'scope':'Original hashed prepared evaluator, real NumPy/SciPy; not full resolver/HTTP/browser/OpenVSP or NASA geometry qualification.','passed':sum(x['status']=='PASS' for x in results),'failed':sum(x['status']=='FAIL' for x in results),'results':results}
(root/'results/curves.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
# Verify previously delivered fixtures and produce a fixture-only copy without modifying bytes.
with zipfile.ZipFile('/mnt/data/SPRINT_04B_Efficient_Input_Agent_Pack.zip') as z:
 manifest=json.loads(z.read('PACK_MANIFEST.json'));checks=[]
 for item in manifest['files']:
  data=z.read(item['path']);actual=hashlib.sha256(data).hexdigest();assert actual==item['sha256'];checks.append({'path':item['path'],'sha256':actual,'bytes':len(data),'matches_original_manifest':True})
 with zipfile.ZipFile('/mnt/data/X57_Fixtures_For_Sprint04B.zip','w',zipfile.ZIP_DEFLATED) as dest:
  for name in z.namelist():
   if name.startswith('fixtures/'): dest.writestr(name,z.read(name))
(root/'results/fixture_verification.json').write_text(json.dumps(checks,indent=2))
print('PACK: all original manifest hashes match,',len(checks),'files checked')

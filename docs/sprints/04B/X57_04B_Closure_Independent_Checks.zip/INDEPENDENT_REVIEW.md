# Independent review — Sprint 04B X-57 closure

## Basis and scope

This review uses the user-uploaded closure report, acceptance matrix, evidence summary,
exported candidate, retained STEP, and the previously supplied X-57 fixture ZIP.
No GitHub checkout, complete product build, Playwright rerun, final per-station
geometry validator, or official NASA surface comparison was performed here.
The local checks below were executed against the actual uploaded data and STEP.
They must not replace the failed official pipeline result.

## 1. Input and identity checks executed

- All five files listed by the supplied fixture `SHA256SUMS.txt` match.
- STEP bytes: 86032477.
- STEP SHA-256: `43c2cd72bebcd3949e0fe0b210aaac9ccbf6918952743fd109ecb0cac2e401d6` (matches reported failed job).
- Exported-candidate raw SHA-256: `45bccd02f73388cd1d6a94c16b870e9f5f9931849834e83eef6f74202d66b737` (matches report).
- Two endpoint stations at 0.20238 and 1; TE = 0 at both.
- All 282 airfoil coordinate pairs (564 scalars across both stations) exactly match the supplied CSV.
- Each of Chord/Twist/Rake/Skew contains 40 PCHIP controls.
- All radii exactly match the physical-unit CSV; all stored values exactly match the corresponding mm-to-normalized conversion (Twist unchanged).
- Largest physical round-trip difference: 7.105427357601002e-15 mm, Chord.
- Thickness remains the documented product measurement, 0.1305533776828919, with two Linear controls. This is not claimed equal to the source-native thickness definition.

## 2. Timing evidence recomputed, not rerun

Recomputed statistics from the 20 samples supplied in `evidence_summary.json`:
- Median: 396.20000000298023 ms.
- p95 (linear interpolation): 429.86500000283127 ms.
- Maximum: 480.5 ms.
- Cold sample recorded by the agent: 412.5 ms.
- Each supplied warm Apply sample records one validation, one preview, zero builds.

These checks establish arithmetic consistency of the submitted evidence; they are
not independent browser latency measurements.

## 3. Read-only OCP inspection executed

Environment: Python 3.13.5, OCP 7.9.3.1.

| Property | Measured |
| --- | ---: |
| Solids | 1 |
| Shells | 1 |
| Faces | 6 |
| Closed shell | True |
| BRepCheck valid | True |
| Non-degenerate free edges | 0 |
| Adaptive volume | 46228.517992522764 mm3 |

This is topology and mass-property evidence only. Chord, Twist, contour/TE
fidelity across all stations, full pipeline round-trip gates, and external NASA
fidelity remain unqualified here.

## 4. Surface representation observation

The two main B-spline faces each have a 1858 by 244 control net:
453,352 control-net entries per main face (906,704 across the two).
The four other faces each have 2 by 244 entries.
These are internal CAD surface control-net entries, not additional user input
stations and not necessarily globally distinct spatial points.

This establishes a dense internal representation. It is a profiling lead, not
proof that it caused the 300-second job timeout. The supplied evidence does not
contain per-stage or per-station duration traces sufficient to attribute the
bottleneck. The 300.2 seconds is recorded elapsed job time at the failing stage,
not proven duration of that stage alone.

## 5. Additional numerical volume diagnostic executed

| Requested adaptive epsilon | Volume mm3 | Returned error estimate |
| --- | ---: | ---: |
| 1e-08 | 46228.518158189043 | 2.67509047219e-08 |
| 1e-09 | 46228.517992522764 | 2.89070774539e-09 |
| 1e-10 | 46228.517992521629 | 3.30095449789e-10 |

The adaptive volume range over these settings is 0.000165667413967 mm3.
The fixed-rule volume is 44930.548296735971 mm3, which is about
2.807725% below the epsilon=1e-9 adaptive result.
This is a numerical integration difference on the same shape, not a measurement
of NASA mismatch. Returned error estimates are recorded, not treated as a
formal proof of all geometric validation requirements.

## 6. Recommended next diagnostic — not another feature sprint

1. Freeze the exact working tree/input identity and retained-STEP hash. Preserve
   the original failed job; do not relabel it successful.
2. Time every stage and each station within the unchanged production geometry
   validator. Use the retained STEP and matching candidate read-only first,
   without rerunning OpenVSP. Allow a longer finite diagnostic budget (e.g.
   900 seconds), clearly distinct from the 300-second production job result.
3. Report PASS/FAIL for the unchanged geometry gates and exact timings. If a
   bottleneck is found, optimize repeated work only; do not drop control points,
   validation stations, contour checks, tolerances, or replace the shape by a mesh.
4. Then run the complete production pipeline on the frozen inputs to demonstrate
   actual product completion under a documented runtime policy.
5. Acquire/check the official source CAD representation independently before
   external NASA fidelity comparison. Source-derived CSVs alone are not that
   comparison geometry. Do not use a previously reconstructed blade as ground truth.

## Review decision

Input integrity: PASS on supplied CSV/candidate data.
Reported interactive-performance arithmetic: confirmed; underlying UI run agent-reported.
Retained STEP topology: independently confirmed PASS (partial scope).
Official X-57 end-to-end job: FAILED / qualification incomplete at timeout.
External NASA geometry fidelity: UNVERIFIED.

The evidence supports retaining the input/performance improvements and focusing
next on completing and profiling final geometry validation, not reopening bulk input.

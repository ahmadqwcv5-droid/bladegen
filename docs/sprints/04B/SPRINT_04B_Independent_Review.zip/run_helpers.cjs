const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),ts=require('typescript');
const root=__dirname, dir=path.join(root,'source/frontend');
require.extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,f);
const imp=require(path.join(dir,'distributionImport.ts'));
const setup=require(path.join(dir,'airfoilStationSetup.ts'));
const {CURVES,CurveHistory}=require(path.join(dir,'curveEditing.ts'));
const original=JSON.parse(fs.readFileSync('/mnt/data/blade_spec.json','utf8'));
const base=structuredClone(original);base.diameter_mm=575.9200184294399;base.root_radius_ratio=.20238;base.reference_axis_x_over_c=.5;base.rotation_direction="normal";
const aircsv=fs.readFileSync('/mnt/data/x57_manual_reference/x57_hlp_airfoil.csv','utf8').trim().split(/\r?\n/);
const profile={type:'coordinates',upper:[],lower:[]};
for(const line of aircsv.slice(1)){const [side,x,y]=line.split(',');profile[side].push([Number(x),Number(y)]);}
base.airfoil_sections=[.20238,1].map(r=>({r_over_R:r,airfoil:structuredClone(profile),trailing_edge_thickness_mm:0}));
for(const d of CURVES){base[d.key].points[0].r_over_R=.20238;}
base.thickness_distribution={interpolation:'linear',points:[{r_over_R:.20238,thickness_ratio:.1305533776828919},{r_over_R:1,thickness_ratio:.1305533776828919}]};
const csv=fs.readFileSync('/mnt/data/x57_manual_reference/x57_hlp_control_points_mm.csv','utf8');
const expected=csv.trim().split(/\r?\n/).slice(1).map(line=>line.split(',').map(Number));
const table=imp.parseDelimitedTable(csv,'actual_x57_fixture.csv'),plan=imp.suggestedImportPlan(table,base);for(const s of Object.values(plan.selections))s.interpolation='pchip';
let candidate;
const results=[];
function test(name,fn){try{fn();results.push({name,status:'PASS'})}catch(e){results.push({name,status:'FAIL',error:String(e)})}}
function parseBuild(text,snapshot=base){const t=imp.parseDelimitedTable(text),p=imp.suggestedImportPlan(t,snapshot);return imp.buildDistributionCandidate(snapshot,t,p)}
test('actual X57 fixture parses exactly 40 rows',()=>{assert.equal(table.rows.length,40);assert.deepEqual(table.headers,['row','r_over_R','chord_mm','twist_deg','rake_mm','skew_mm']);});
test('actual X57 all 160 values and radii map correctly',()=>{candidate=imp.buildDistributionCandidate(base,table,plan).spec; for(const [d,index]of CURVES.slice(0,4).map((d,i)=>[d,i])){assert.equal(candidate[d.key].points.length,40);expected.forEach((row,i)=>{assert.equal(candidate[d.key].points[i].r_over_R,row[1]);assert.equal(candidate[d.key].points[i][d.valueKey],d.name==='twist'?row[index+2]:row[index+2]/(base.diameter_mm/2));});}});
test('import preserves profile coordinates and two airfoil stations',()=>assert.deepEqual(candidate.airfoil_sections,base.airfoil_sections));
test('import preserves two-point thickness and global dimensions',()=>{assert.deepEqual(candidate.thickness_distribution,base.thickness_distribution);for(const f of ['name','diameter_mm','root_radius_ratio','reference_axis_x_over_c','rotation_direction'])assert.equal(candidate[f],base[f]);});
test('builder is nonmutating',()=>{const before=JSON.stringify(base);imp.buildDistributionCandidate(base,table,plan);assert.equal(JSON.stringify(base),before);});
test('CSV and TSV same values',()=>{assert.deepEqual(parseBuild(csv.replaceAll(',','\t')).spec,parseBuild(csv).spec);});
test('BOM and CRLF preserved',()=>assert.deepEqual(parseBuild('\uFEFF'+csv.replace(/\r?\n/g,'\r\n')).spec,parseBuild(csv).spec));
test('partial twist import allows independent grid',()=>{const result=parseBuild('r_over_R,twist_deg\n.20238,50\n.333,35\n.9,25\n1,20',candidate).spec;assert.equal(result.twist_distribution.points.length,4);assert.deepEqual(result.chord_distribution,candidate.chord_distribution);assert.deepEqual(result.airfoil_sections,candidate.airfoil_sections);});
test('negative skew and rake retained',()=>{assert(candidate.skew_distribution.points.some(p=>p.skew_over_R<0));assert(candidate.rake_distribution.points.every(p=>p.rake_over_R<0));});
test('numeric value precision and exponent notation',()=>assert.equal(parseBuild('r_over_R,chord_mm\n.20238,7.87654321e1\n1,3e1').spec.chord_distribution.points[0].chord_over_R,78.7654321/(base.diameter_mm/2)));
test('explicit normalized chord at another diameter',()=>{const result=parseBuild('r_over_R,chord_over_R\n.20238,.12345678912345\n1,.03',{...base,diameter_mm:720}).spec;assert.equal(result.chord_distribution.points[0].chord_over_R,.12345678912345);});
test('physical chord at 400 and 720 diameters',()=>{for(const d of [400,720])assert.equal(parseBuild('r_over_R,chord_mm\n.20238,60\n1,30',{...base,diameter_mm:d}).spec.chord_distribution.points[0].chord_over_R,60/(d/2));});
test('duplicate radii rejected',()=>assert.throws(()=>parseBuild('r_over_R,chord_mm\n.20238,60\n.20238,50\n1,30'),/duplicate/));
test('blank required value rejected',()=>assert.throws(()=>parseBuild('r_over_R,chord_mm\n.20238,\n1,30'),/required/));
test('nonfinite value rejected',()=>assert.throws(()=>parseBuild('r_over_R,chord_mm\n.20238,Infinity\n1,30'),/finite/));
test('mismatching root rejected',()=>assert.throws(()=>parseBuild('r_over_R,chord_mm\n.2,60\n1,30'),/root/));
test('descending rows require explicit sort',()=>{const t=imp.parseDelimitedTable('r_over_R,chord_mm\n1,30\n.20238,60'),p=imp.suggestedImportPlan(t,base);assert.throws(()=>imp.buildDistributionCandidate(base,t,p),/not increasing/);assert.equal(imp.buildDistributionCandidate(base,imp.sortTableByRadius(t,'r_over_R'),p).spec.chord_distribution.points[0].r_over_R,.20238);});
test('unknown field needs explicit exclusion',()=>{const t=imp.parseDelimitedTable('r_over_R,chord_mm,note\n.20238,60,hello\n1,30,test'),p=imp.suggestedImportPlan(t,base);assert.throws(()=>imp.buildDistributionCandidate(base,t,p),/exclude/);p.excludedColumns=['note'];assert.equal(imp.buildDistributionCandidate(base,t,p).summaries.length,1);});
test('history restores all four curves as one operation',()=>{const h=new CurveHistory(50);h.push({before:base,after:candidate,label:'Import X57'});assert.deepEqual(h.undo(candidate),base);assert(!h.canUndo);assert.deepEqual(h.redo(base),candidate);});
const options={mode:'uniform',count:2,explicitRadii:'',sourceStationIndex:0,commonTrailingEdgeMm:0,preserveMatchingStations:false,constantThicknessDistribution:true};
for(const n of [2,3,5,8])test(`bulk station setup ${n} count`,()=>{const p=setup.buildStationSetupCandidate(candidate,{...options,count:n}).spec;assert.equal(p.airfoil_sections.length,n);assert.equal(p.airfoil_sections[0].r_over_R,.20238);assert.equal(p.airfoil_sections.at(-1).r_over_R,1);assert(p.airfoil_sections.every(s=>s.trailing_edge_thickness_mm===0));assert.deepEqual(p.chord_distribution,candidate.chord_distribution);});
test('explicit nonuniform station grid',()=>{const p=setup.buildStationSetupCandidate(candidate,{...options,mode:'explicit',explicitRadii:'.20238 .45 .94 1'}).spec;assert.deepEqual(p.airfoil_sections.map(s=>s.r_over_R),[.20238,.45,.94,1]);});
// Separate exploratory probes: these are deliberately NOT counted as passing requirements.
const exploratory=[];
for(const [name,text] of [['malformed quote embedded in numeric cell','r_over_R,chord_mm\n.20238,6"4"\n1,30'],['hexadecimal numeric syntax','r_over_R,chord_mm\n.20238,0x40\n1,30']]){try{const v=parseBuild(text).spec.chord_distribution.points[0].chord_over_R*(base.diameter_mm/2);exploratory.push({name,accepted:true,resulting_chord_mm:v})}catch(e){exploratory.push({name,accepted:false,error:String(e)})}}
const report={runtime:process.version,scope:'Actual hashed source modules in isolated Node transpilation; no React/browser/backend validation/CAD execution.',passed:results.filter(r=>r.status==='PASS').length,failed:results.filter(r=>r.status==='FAIL').length,results,exploratory};
fs.writeFileSync(path.join(root,'results/helpers.json'),JSON.stringify(report,null,2));
// Audit-only output; not a UI-imported candidate and not CAD-qualified.
fs.writeFileSync(path.join(root,'results/x57_candidate_HELPER_ONLY.json'),JSON.stringify(candidate,null,2));
console.log(JSON.stringify(report,null,2));
if(report.failed)process.exitCode=1;

"""Read-only inspection: not a replacement for official pipeline qualification."""
from pathlib import Path
import json,time,hashlib,platform
import OCP
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.TopAbs import TopAbs_SOLID,TopAbs_SHELL,TopAbs_FACE,TopAbs_EDGE
from OCP.TopTools import TopTools_IndexedMapOfShape,TopTools_IndexedDataMapOfShapeListOfShape
from OCP.TopExp import TopExp
from OCP.TopoDS import TopoDS
from OCP.BRep import BRep_Tool
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_BSplineSurface
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
root=Path('/mnt/data/review_04b_closure');src=Path('/mnt/data/blade_solid.step')
result={'scope':'Partial read-only STEP inspection; no NASA comparison or full pipeline qualification.','input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'bytes':src.stat().st_size,'environment':{'python':platform.python_version(),'ocp':getattr(OCP,'__version__','unknown')},'timings_seconds':{}}
started=time.monotonic()
def save(stage):
    result['last_completed_stage']=stage;result['elapsed_seconds']=time.monotonic()-started
    (root/'independent_step_inspection.json').write_text(json.dumps(result,indent=2))
    print(stage,round(result['elapsed_seconds'],3),flush=True)
r=STEPControl_Reader();t=time.monotonic();status=r.ReadFile(str(src))
if status!=IFSelect_RetDone:raise RuntimeError(f'ReadFile status {status}')
result['timings_seconds']['read_step']=time.monotonic()-t;save('step_parsed')
t=time.monotonic();result['transferred_roots']=r.TransferRoots();sh=r.OneShape()
if sh.IsNull():raise RuntimeError('Null shape')
result['timings_seconds']['transfer_roots']=time.monotonic()-t;result['shape_type']=str(sh.ShapeType());save('shape_loaded')
maps={}
for name,typ in [('solids',TopAbs_SOLID),('shells',TopAbs_SHELL),('faces',TopAbs_FACE),('edges',TopAbs_EDGE)]:
    m=TopTools_IndexedMapOfShape();TopExp.MapShapes_s(sh,typ,m);maps[name]=m;result[name]=m.Extent()
result['shell_closed']=[BRep_Tool.IsClosed_s(maps['shells'].FindKey(i)) for i in range(1,maps['shells'].Extent()+1)]
adj=TopTools_IndexedDataMapOfShapeListOfShape();TopExp.MapShapesAndAncestors_s(sh,TopAbs_EDGE,TopAbs_FACE,adj)
free=deg=0;hist={}
for i in range(1,adj.Extent()+1):
    n=adj.FindFromIndex(i).Size();hist[str(n)]=hist.get(str(n),0)+1
    if n==1:
        if BRep_Tool.Degenerated_s(TopoDS.Edge_s(adj.FindKey(i))):deg+=1
        else:free+=1
result.update(non_degenerate_free_edges=free,single_face_degenerate_edges=deg,edge_face_adjacency=hist);save('topology_counts')
t=time.monotonic();result['brep_valid']=BRepCheck_Analyzer(sh).IsValid();result['timings_seconds']['brep_check']=time.monotonic()-t;save('brep_checked')
surfaces=[]
for i in range(1,maps['faces'].Extent()+1):
    ad=BRepAdaptor_Surface(TopoDS.Face_s(maps['faces'].FindKey(i)));d={'face':i,'type':str(ad.GetType())}
    if ad.GetType()==GeomAbs_BSplineSurface:
        bs=ad.BSpline();d.update(u_degree=bs.UDegree(),v_degree=bs.VDegree(),u_poles=bs.NbUPoles(),v_poles=bs.NbVPoles(),u_knots=bs.NbUKnots(),v_knots=bs.NbVKnots(),control_net_points=bs.NbUPoles()*bs.NbVPoles())
    surfaces.append(d)
result['surfaces']=surfaces;save('surface_structure')
t=time.monotonic();box=Bnd_Box();BRepBndLib.AddOptimal_s(sh,box,False,False);b=box.Get()
result['bbox']={'min_mm':list(b[:3]),'max_mm':list(b[3:]),'extent_mm':[b[i+3]-b[i] for i in range(3)]};result['timings_seconds']['bbox']=time.monotonic()-t;save('bounding_box')
t=time.monotonic();props=GProp_GProps();err=BRepGProp.VolumePropertiesGK_s(sh,props,1e-9,True,True,False,False,False)
result['volume']={'mm3':props.Mass(),'method':'BRepGProp.VolumePropertiesGK_s','eps':1e-9,'is_use_span':True,'estimated_relative_error':err};result['timings_seconds']['volume_gk']=time.monotonic()-t;save('adaptive_volume')
result['finished']=True;save('done');print(json.dumps(result,indent=2),flush=True)

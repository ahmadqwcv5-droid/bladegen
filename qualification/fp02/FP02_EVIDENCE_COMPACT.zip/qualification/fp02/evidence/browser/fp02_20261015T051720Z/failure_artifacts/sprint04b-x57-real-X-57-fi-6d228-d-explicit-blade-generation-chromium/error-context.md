# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sprint04b-x57.spec.ts >> real X-57 fixtures flow through reviewed UI input, export, and explicit blade generation
- Location: e2e/sprint04b-x57.spec.ts:267:1

# Error details

```
Error: spawnSync git ENOBUFS
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - paragraph [ref=e6]: LEVEL 1 · SPRINT 04B
      - heading "BladeGen" [level=1] [ref=e7]
      - paragraph [ref=e8]: One validated blade → OCP propeller assembly → independently qualified solid
    - generic [ref=e9]:
      - button "New" [ref=e10] [cursor=pointer]
      - button "Open JSON" [ref=e11] [cursor=pointer]
      - button "Export JSON" [ref=e12] [cursor=pointer]
      - button "Load Example" [ref=e13] [cursor=pointer]
      - button "Reset" [ref=e14] [cursor=pointer]
      - button "Undo curve edit" [ref=e15] [cursor=pointer]: Undo
      - button "Redo curve edit" [disabled] [ref=e16] [cursor=pointer]: Redo
      - button "Validate" [ref=e17] [cursor=pointer]
      - button "Generate Blade" [ref=e18] [cursor=pointer]
  - group "Design mode" [ref=e19]:
    - button "Single Blade" [pressed] [ref=e20] [cursor=pointer]
    - button "Full Propeller" [ref=e21] [cursor=pointer]
  - generic [ref=e22]:
    - strong [ref=e23]: Current design · Input checks passed
    - text: — Build, STEP topology, and independent geometry validation passed
  - generic [ref=e24]:
    - generic [ref=e25]:
      - generic [ref=e26]:
        - heading "Global settings" [level=2] [ref=e27]
        - generic [ref=e28]:
          - generic [ref=e29]:
            - text: Name
            - textbox "Name" [ref=e30]: X57_HLP_manual_test
          - generic [ref=e31]:
            - text: Diameter (mm)
            - spinbutton "Diameter" [ref=e33]: "575.9200184294399"
          - generic [ref=e34]:
            - text: Root r/R
            - spinbutton "Root radius" [ref=e36]: "0.20238"
          - generic [ref=e37]:
            - text: Reference x/c
            - spinbutton "Reference axis" [ref=e39]: "0.5"
          - generic [ref=e40]:
            - text: Rotation
            - combobox "Rotation" [ref=e41]:
              - option "Normal" [selected]
              - option "Reverse"
      - generic [ref=e42]:
        - generic [ref=e43]:
          - heading "Airfoil Stations (2)" [level=2] [ref=e44]
          - generic [ref=e45]:
            - button "Add Airfoil Station" [ref=e46] [cursor=pointer]
            - button "Set Up Airfoil Stations" [ref=e47] [cursor=pointer]
            - button "Apply Profile to Selected Stations" [disabled] [ref=e48] [cursor=pointer]
        - paragraph [ref=e49]: Inspecting Station 1 · r/R 0.2024
        - table [ref=e51]:
          - rowgroup [ref=e52]:
            - row [ref=e53]:
              - columnheader "Select" [ref=e54]
              - columnheader "r/R" [ref=e55]
              - columnheader "Profile" [ref=e56]
              - columnheader "TE mm" [ref=e57]
              - columnheader "Effective t/c" [ref=e58]
              - columnheader "Override" [ref=e59]
              - columnheader "Status" [ref=e60]
              - columnheader [ref=e61]
          - rowgroup [ref=e62]:
            - row [ref=e63]:
              - cell [ref=e64]:
                - checkbox "Select airfoil station 1" [ref=e65]
              - cell [ref=e66]:
                - spinbutton "Airfoil radius 1" [disabled] [ref=e68]: "0.20238"
              - cell "X-57 HLP source profile Choose from Library Inspect Compare as A" [ref=e69]:
                - generic [ref=e70]: X-57 HLP source profile
                - group [ref=e71]:
                  - generic "Embedded coordinates" [ref=e72]
                - generic [ref=e73]:
                  - button "Choose from Library" [ref=e74] [cursor=pointer]
                  - button "Inspect" [ref=e75] [cursor=pointer]
                  - button "Compare as A" [ref=e76] [cursor=pointer]
              - cell [ref=e77]:
                - spinbutton "TE thickness 1" [ref=e79]: "0"
              - cell "0.1306" [ref=e80]
              - cell "natural coordinate t/c" [ref=e81]
              - cell "Selected" [ref=e82]
              - cell [ref=e83]:
                - button "Remove" [disabled] [ref=e84] [cursor=pointer]
            - row [ref=e85]:
              - cell [ref=e86]:
                - checkbox "Select airfoil station 2" [ref=e87]
              - cell [ref=e88]:
                - spinbutton "Airfoil radius 2" [disabled] [ref=e90]: "1"
              - cell "X-57 HLP source profile Choose from Library Inspect Compare as A" [ref=e91]:
                - generic [ref=e92]: X-57 HLP source profile
                - group [ref=e93]:
                  - generic "Embedded coordinates" [ref=e94]
                - generic [ref=e95]:
                  - button "Choose from Library" [ref=e96] [cursor=pointer]
                  - button "Inspect" [ref=e97] [cursor=pointer]
                  - button "Compare as A" [ref=e98] [cursor=pointer]
              - cell [ref=e99]:
                - spinbutton "TE thickness 2" [ref=e101]: "0"
              - cell "0.1306" [ref=e102]
              - cell "natural coordinate t/c" [ref=e103]
              - cell "—" [ref=e104]
              - cell [ref=e105]:
                - button "Remove" [disabled] [ref=e106] [cursor=pointer]
        - paragraph [ref=e107]: Library selections embed exact coordinates in BladeSpec. Physical trailing-edge thickness remains an independent millimeter requirement.
        - group "Station inspection mode" [ref=e108]:
          - button "Single Station" [pressed] [ref=e109] [cursor=pointer]
          - button "Compare Stations" [ref=e110] [cursor=pointer]
        - paragraph [ref=e111]: Canonical design preview is current; no OpenVSP process was run.
        - region "2D Airfoil Inspector" [ref=e112]:
          - generic [ref=e113]:
            - generic [ref=e114]:
              - paragraph [ref=e115]: Design-definition preview
              - heading "Imported coordinate profile at r/R 0.2024" [level=3] [ref=e116]
            - group "Airfoil definition view" [ref=e117]:
              - button "Source Profile" [ref=e118] [cursor=pointer]
              - button "Resolved Design Profile" [pressed] [ref=e119] [cursor=pointer]
          - img "Imported coordinate profile at r/R 0.2024 resolved airfoil coordinates" [ref=e120]
          - generic [ref=e125]:
            - generic [ref=e126]: LE · x/c 0
            - generic [ref=e127]: x/c → · equal x/y scale
            - generic [ref=e128]: TE · x/c 1
          - generic [ref=e129]:
            - term [ref=e130]: Local chord
            - definition [ref=e131]: 37.651 mm
            - term [ref=e132]: Nominal / effective t/c
            - definition [ref=e133]: 0.1306 / 0.1306
            - term [ref=e134]: Geometric max t/c
            - definition [ref=e135]: 0.13055 at x/c 0.289
            - term [ref=e136]: Maximum camber
            - definition [ref=e137]: 0.06577 at x/c 0.468
            - term [ref=e138]: Source TE gap
            - definition [ref=e139]: 0.000% chord
            - term [ref=e140]: Requested physical TE
            - definition [ref=e141]: 0.000 mm
          - paragraph [ref=e142]: canonical design definition; final CAD validation not yet performed
      - generic [ref=e143]:
        - generic [ref=e144]:
          - generic [ref=e145]:
            - heading "Independent Spanwise Distributions" [level=2] [ref=e146]
            - paragraph [ref=e147]: Distribution controls are independent from airfoil stations and computed preview samples.
          - button "Import Distributions" [ref=e148] [cursor=pointer]
        - generic [ref=e149]:
          - generic [ref=e150]:
            - generic [ref=e151]: Undo Import Chord/Twist/Rake/Skew distributions · Nothing to redo
            - generic [ref=e152]: Ready
          - group "Distribution chart selection" [ref=e153]:
            - button "Chord" [pressed] [ref=e154] [cursor=pointer]
            - button "Twist" [ref=e155] [cursor=pointer]
            - button "Rake" [ref=e156] [cursor=pointer]
            - button "Skew" [ref=e157] [cursor=pointer]
            - button "Thickness" [ref=e158] [cursor=pointer]
          - generic [ref=e159]:
            - generic [ref=e160]:
              - heading "Chord Distribution" [level=3] [ref=e161]
              - generic [ref=e162]: PCHIP · mm
            - img "Chord Distribution canonical pchip distribution in mm" [ref=e163]:
              - generic [ref=e164]: r/R 0.20
              - generic [ref=e165]: "1.00"
              - generic [ref=e166]: "81.868"
              - generic [ref=e167]: "-2.169"
              - slider "Chord Distribution control 1, r/R 0.2024, 37.6508 mm" [ref=e171]
              - slider "Chord Distribution control 2, r/R 0.2095, 39.8134 mm" [ref=e174]
              - slider "Chord Distribution control 3, r/R 0.2230, 44.8987 mm" [ref=e177]
              - slider "Chord Distribution control 4, r/R 0.2418, 51.8213 mm" [ref=e180]
              - slider "Chord Distribution control 5, r/R 0.2647, 59.4033 mm" [ref=e183]
              - slider "Chord Distribution control 6, r/R 0.2906, 66.9565 mm" [ref=e186]
              - slider "Chord Distribution control 7, r/R 0.3186, 72.3644 mm" [ref=e189]
              - slider "Chord Distribution control 8, r/R 0.3481, 73.7350 mm" [ref=e192]
              - slider "Chord Distribution control 9, r/R 0.3785, 71.6157 mm" [ref=e195]
              - slider "Chord Distribution control 10, r/R 0.4096, 68.1976 mm" [ref=e198]
              - slider "Chord Distribution control 11, r/R 0.4409, 64.0020 mm" [ref=e201]
              - slider "Chord Distribution control 12, r/R 0.4722, 58.5135 mm" [ref=e204]
              - slider "Chord Distribution control 13, r/R 0.5034, 53.6786 mm" [ref=e207]
              - slider "Chord Distribution control 14, r/R 0.5344, 50.2173 mm" [ref=e210]
              - slider "Chord Distribution control 15, r/R 0.5649, 47.3867 mm" [ref=e213]
              - slider "Chord Distribution control 16, r/R 0.5949, 44.8699 mm" [ref=e216]
              - slider "Chord Distribution control 17, r/R 0.6243, 42.6411 mm" [ref=e219]
              - slider "Chord Distribution control 18, r/R 0.6530, 40.7060 mm" [ref=e222]
              - slider "Chord Distribution control 19, r/R 0.6808, 38.9725 mm" [ref=e225]
              - slider "Chord Distribution control 20, r/R 0.7079, 37.4118 mm" [ref=e228]
              - slider "Chord Distribution control 21, r/R 0.7340, 36.0324 mm" [ref=e231]
              - slider "Chord Distribution control 22, r/R 0.7592, 34.7769 mm" [ref=e234]
              - slider "Chord Distribution control 23, r/R 0.7833, 33.6424 mm" [ref=e237]
              - slider "Chord Distribution control 24, r/R 0.8063, 32.6144 mm" [ref=e240]
              - slider "Chord Distribution control 25, r/R 0.8282, 31.6583 mm" [ref=e243]
              - slider "Chord Distribution control 26, r/R 0.8490, 30.7743 mm" [ref=e246]
              - slider "Chord Distribution control 27, r/R 0.8685, 29.9853 mm" [ref=e249]
              - slider "Chord Distribution control 28, r/R 0.8868, 29.2683 mm" [ref=e252]
              - slider "Chord Distribution control 29, r/R 0.9038, 28.4985 mm" [ref=e255]
              - slider "Chord Distribution control 30, r/R 0.9195, 27.6387 mm" [ref=e258]
              - slider "Chord Distribution control 31, r/R 0.9339, 26.8189 mm" [ref=e261]
              - slider "Chord Distribution control 32, r/R 0.9469, 25.9213 mm" [ref=e264]
              - slider "Chord Distribution control 33, r/R 0.9585, 24.2580 mm" [ref=e267]
              - slider "Chord Distribution control 34, r/R 0.9687, 21.4893 mm" [ref=e270]
              - slider "Chord Distribution control 35, r/R 0.9775, 17.9157 mm" [ref=e273]
              - slider "Chord Distribution control 36, r/R 0.9849, 14.2748 mm" [ref=e276]
              - slider "Chord Distribution control 37, r/R 0.9908, 11.0499 mm" [ref=e279]
              - slider "Chord Distribution control 38, r/R 0.9952, 8.5383 mm" [ref=e282]
              - slider "Chord Distribution control 39, r/R 0.9981, 6.8209 mm" [ref=e285]
              - slider "Chord Distribution control 40, r/R 1.0000, 5.9637 mm" [ref=e288]
            - paragraph [ref=e289]: Hover for canonical values · drag or use arrow keys on a marker · markers are user controls
        - generic [ref=e290]:
          - generic [ref=e291]:
            - generic [ref=e292]:
              - heading "Chord (40)" [level=3] [ref=e293]
              - button "Add Control Point" [ref=e294] [cursor=pointer]
            - generic [ref=e295]:
              - text: Interpolation
              - combobox "Chord interpolation" [ref=e296]:
                - option "Linear"
                - option "PCHIP" [selected]
            - table [ref=e298]:
              - rowgroup [ref=e299]:
                - row [ref=e300]:
                  - columnheader "r/R" [ref=e301]
                  - columnheader "Chord (mm)" [ref=e302]
                  - columnheader [ref=e303]
              - rowgroup [ref=e304]:
                - row [ref=e305]:
                  - cell [ref=e306]:
                    - spinbutton "Chord radius 1" [disabled] [ref=e308]: "0.20238"
                  - cell [ref=e309]:
                    - spinbutton "Chord value 1" [ref=e311]: "37.651"
                  - cell [ref=e312]:
                    - button "Remove" [disabled] [ref=e313] [cursor=pointer]
                - row [ref=e314]:
                  - cell [ref=e315]:
                    - spinbutton "Chord radius 2" [ref=e317]: "0.20949"
                  - cell [ref=e318]:
                    - spinbutton "Chord value 2" [ref=e320]: "39.813"
                  - cell [ref=e321]:
                    - button "Remove" [ref=e322] [cursor=pointer]
                - row [ref=e323]:
                  - cell [ref=e324]:
                    - spinbutton "Chord radius 3" [ref=e326]: "0.22302"
                  - cell [ref=e327]:
                    - spinbutton "Chord value 3" [ref=e329]: "44.899"
                  - cell [ref=e330]:
                    - button "Remove" [ref=e331] [cursor=pointer]
                - row [ref=e332]:
                  - cell [ref=e333]:
                    - spinbutton "Chord radius 4" [ref=e335]: "0.24183"
                  - cell [ref=e336]:
                    - spinbutton "Chord value 4" [ref=e338]: "51.821"
                  - cell [ref=e339]:
                    - button "Remove" [ref=e340] [cursor=pointer]
                - row [ref=e341]:
                  - cell [ref=e342]:
                    - spinbutton "Chord radius 5" [ref=e344]: "0.26472"
                  - cell [ref=e345]:
                    - spinbutton "Chord value 5" [ref=e347]: "59.403"
                  - cell [ref=e348]:
                    - button "Remove" [ref=e349] [cursor=pointer]
                - row [ref=e350]:
                  - cell [ref=e351]:
                    - spinbutton "Chord radius 6" [ref=e353]: "0.29061"
                  - cell [ref=e354]:
                    - spinbutton "Chord value 6" [ref=e356]: "66.956"
                  - cell [ref=e357]:
                    - button "Remove" [ref=e358] [cursor=pointer]
                - row [ref=e359]:
                  - cell [ref=e360]:
                    - spinbutton "Chord radius 7" [ref=e362]: "0.31863"
                  - cell [ref=e363]:
                    - spinbutton "Chord value 7" [ref=e365]: "72.364"
                  - cell [ref=e366]:
                    - button "Remove" [ref=e367] [cursor=pointer]
                - row [ref=e368]:
                  - cell [ref=e369]:
                    - spinbutton "Chord radius 8" [ref=e371]: "0.34811"
                  - cell [ref=e372]:
                    - spinbutton "Chord value 8" [ref=e374]: "73.735"
                  - cell [ref=e375]:
                    - button "Remove" [ref=e376] [cursor=pointer]
                - row [ref=e377]:
                  - cell [ref=e378]:
                    - spinbutton "Chord radius 9" [ref=e380]: "0.37855"
                  - cell [ref=e381]:
                    - spinbutton "Chord value 9" [ref=e383]: "71.616"
                  - cell [ref=e384]:
                    - button "Remove" [ref=e385] [cursor=pointer]
                - row [ref=e386]:
                  - cell [ref=e387]:
                    - spinbutton "Chord radius 10" [ref=e389]: "0.40957"
                  - cell [ref=e390]:
                    - spinbutton "Chord value 10" [ref=e392]: "68.198"
                  - cell [ref=e393]:
                    - button "Remove" [ref=e394] [cursor=pointer]
                - row [ref=e395]:
                  - cell [ref=e396]:
                    - spinbutton "Chord radius 11" [ref=e398]: "0.44087"
                  - cell [ref=e399]:
                    - spinbutton "Chord value 11" [ref=e401]: "64.002"
                  - cell [ref=e402]:
                    - button "Remove" [ref=e403] [cursor=pointer]
                - row [ref=e404]:
                  - cell [ref=e405]:
                    - spinbutton "Chord radius 12" [ref=e407]: "0.47223"
                  - cell [ref=e408]:
                    - spinbutton "Chord value 12" [ref=e410]: "58.513"
                  - cell [ref=e411]:
                    - button "Remove" [ref=e412] [cursor=pointer]
                - row [ref=e413]:
                  - cell [ref=e414]:
                    - spinbutton "Chord radius 13" [ref=e416]: "0.50345"
                  - cell [ref=e417]:
                    - spinbutton "Chord value 13" [ref=e419]: "53.679"
                  - cell [ref=e420]:
                    - button "Remove" [ref=e421] [cursor=pointer]
                - row [ref=e422]:
                  - cell [ref=e423]:
                    - spinbutton "Chord radius 14" [ref=e425]: "0.53439"
                  - cell [ref=e426]:
                    - spinbutton "Chord value 14" [ref=e428]: "50.217"
                  - cell [ref=e429]:
                    - button "Remove" [ref=e430] [cursor=pointer]
                - row [ref=e431]:
                  - cell [ref=e432]:
                    - spinbutton "Chord radius 15" [ref=e434]: "0.56491"
                  - cell [ref=e435]:
                    - spinbutton "Chord value 15" [ref=e437]: "47.387"
                  - cell [ref=e438]:
                    - button "Remove" [ref=e439] [cursor=pointer]
                - row [ref=e440]:
                  - cell [ref=e441]:
                    - spinbutton "Chord radius 16" [ref=e443]: "0.59491"
                  - cell [ref=e444]:
                    - spinbutton "Chord value 16" [ref=e446]: "44.87"
                  - cell [ref=e447]:
                    - button "Remove" [ref=e448] [cursor=pointer]
                - row [ref=e449]:
                  - cell [ref=e450]:
                    - spinbutton "Chord radius 17" [ref=e452]: "0.62429"
                  - cell [ref=e453]:
                    - spinbutton "Chord value 17" [ref=e455]: "42.641"
                  - cell [ref=e456]:
                    - button "Remove" [ref=e457] [cursor=pointer]
                - row [ref=e458]:
                  - cell [ref=e459]:
                    - spinbutton "Chord radius 18" [ref=e461]: "0.65296"
                  - cell [ref=e462]:
                    - spinbutton "Chord value 18" [ref=e464]: "40.706"
                  - cell [ref=e465]:
                    - button "Remove" [ref=e466] [cursor=pointer]
                - row [ref=e467]:
                  - cell [ref=e468]:
                    - spinbutton "Chord radius 19" [ref=e470]: "0.68085"
                  - cell [ref=e471]:
                    - spinbutton "Chord value 19" [ref=e473]: "38.973"
                  - cell [ref=e474]:
                    - button "Remove" [ref=e475] [cursor=pointer]
                - row [ref=e476]:
                  - cell [ref=e477]:
                    - spinbutton "Chord radius 20" [ref=e479]: "0.70789"
                  - cell [ref=e480]:
                    - spinbutton "Chord value 20" [ref=e482]: "37.412"
                  - cell [ref=e483]:
                    - button "Remove" [ref=e484] [cursor=pointer]
                - row [ref=e485]:
                  - cell [ref=e486]:
                    - spinbutton "Chord radius 21" [ref=e488]: "0.73401"
                  - cell [ref=e489]:
                    - spinbutton "Chord value 21" [ref=e491]: "36.032"
                  - cell [ref=e492]:
                    - button "Remove" [ref=e493] [cursor=pointer]
                - row [ref=e494]:
                  - cell [ref=e495]:
                    - spinbutton "Chord radius 22" [ref=e497]: "0.75916"
                  - cell [ref=e498]:
                    - spinbutton "Chord value 22" [ref=e500]: "34.777"
                  - cell [ref=e501]:
                    - button "Remove" [ref=e502] [cursor=pointer]
                - row [ref=e503]:
                  - cell [ref=e504]:
                    - spinbutton "Chord radius 23" [ref=e506]: "0.78328"
                  - cell [ref=e507]:
                    - spinbutton "Chord value 23" [ref=e509]: "33.642"
                  - cell [ref=e510]:
                    - button "Remove" [ref=e511] [cursor=pointer]
                - row [ref=e512]:
                  - cell [ref=e513]:
                    - spinbutton "Chord radius 24" [ref=e515]: "0.80632"
                  - cell [ref=e516]:
                    - spinbutton "Chord value 24" [ref=e518]: "32.614"
                  - cell [ref=e519]:
                    - button "Remove" [ref=e520] [cursor=pointer]
                - row [ref=e521]:
                  - cell [ref=e522]:
                    - spinbutton "Chord radius 25" [ref=e524]: "0.82823"
                  - cell [ref=e525]:
                    - spinbutton "Chord value 25" [ref=e527]: "31.658"
                  - cell [ref=e528]:
                    - button "Remove" [ref=e529] [cursor=pointer]
                - row [ref=e530]:
                  - cell [ref=e531]:
                    - spinbutton "Chord radius 26" [ref=e533]: "0.84898"
                  - cell [ref=e534]:
                    - spinbutton "Chord value 26" [ref=e536]: "30.774"
                  - cell [ref=e537]:
                    - button "Remove" [ref=e538] [cursor=pointer]
                - row [ref=e539]:
                  - cell [ref=e540]:
                    - spinbutton "Chord radius 27" [ref=e542]: "0.86852"
                  - cell [ref=e543]:
                    - spinbutton "Chord value 27" [ref=e545]: "29.985"
                  - cell [ref=e546]:
                    - button "Remove" [ref=e547] [cursor=pointer]
                - row [ref=e548]:
                  - cell [ref=e549]:
                    - spinbutton "Chord radius 28" [ref=e551]: "0.88681"
                  - cell [ref=e552]:
                    - spinbutton "Chord value 28" [ref=e554]: "29.268"
                  - cell [ref=e555]:
                    - button "Remove" [ref=e556] [cursor=pointer]
                - row [ref=e557]:
                  - cell [ref=e558]:
                    - spinbutton "Chord radius 29" [ref=e560]: "0.90383"
                  - cell [ref=e561]:
                    - spinbutton "Chord value 29" [ref=e563]: "28.499"
                  - cell [ref=e564]:
                    - button "Remove" [ref=e565] [cursor=pointer]
                - row [ref=e566]:
                  - cell [ref=e567]:
                    - spinbutton "Chord radius 30" [ref=e569]: "0.91954"
                  - cell [ref=e570]:
                    - spinbutton "Chord value 30" [ref=e572]: "27.639"
                  - cell [ref=e573]:
                    - button "Remove" [ref=e574] [cursor=pointer]
                - row [ref=e575]:
                  - cell [ref=e576]:
                    - spinbutton "Chord radius 31" [ref=e578]: "0.93391"
                  - cell [ref=e579]:
                    - spinbutton "Chord value 31" [ref=e581]: "26.819"
                  - cell [ref=e582]:
                    - button "Remove" [ref=e583] [cursor=pointer]
                - row [ref=e584]:
                  - cell [ref=e585]:
                    - spinbutton "Chord radius 32" [ref=e587]: "0.94691"
                  - cell [ref=e588]:
                    - spinbutton "Chord value 32" [ref=e590]: "25.921"
                  - cell [ref=e591]:
                    - button "Remove" [ref=e592] [cursor=pointer]
                - row [ref=e593]:
                  - cell [ref=e594]:
                    - spinbutton "Chord radius 33" [ref=e596]: "0.95853"
                  - cell [ref=e597]:
                    - spinbutton "Chord value 33" [ref=e599]: "24.258"
                  - cell [ref=e600]:
                    - button "Remove" [ref=e601] [cursor=pointer]
                - row [ref=e602]:
                  - cell [ref=e603]:
                    - spinbutton "Chord radius 34" [ref=e605]: "0.96874"
                  - cell [ref=e606]:
                    - spinbutton "Chord value 34" [ref=e608]: "21.489"
                  - cell [ref=e609]:
                    - button "Remove" [ref=e610] [cursor=pointer]
                - row [ref=e611]:
                  - cell [ref=e612]:
                    - spinbutton "Chord radius 35" [ref=e614]: "0.97753"
                  - cell [ref=e615]:
                    - spinbutton "Chord value 35" [ref=e617]: "17.916"
                  - cell [ref=e618]:
                    - button "Remove" [ref=e619] [cursor=pointer]
                - row [ref=e620]:
                  - cell [ref=e621]:
                    - spinbutton "Chord radius 36" [ref=e623]: "0.98488"
                  - cell [ref=e624]:
                    - spinbutton "Chord value 36" [ref=e626]: "14.275"
                  - cell [ref=e627]:
                    - button "Remove" [ref=e628] [cursor=pointer]
                - row [ref=e629]:
                  - cell [ref=e630]:
                    - spinbutton "Chord radius 37" [ref=e632]: "0.99077"
                  - cell [ref=e633]:
                    - spinbutton "Chord value 37" [ref=e635]: "11.05"
                  - cell [ref=e636]:
                    - button "Remove" [ref=e637] [cursor=pointer]
                - row [ref=e638]:
                  - cell [ref=e639]:
                    - spinbutton "Chord radius 38" [ref=e641]: "0.99519"
                  - cell [ref=e642]:
                    - spinbutton "Chord value 38" [ref=e644]: "8.538"
                  - cell [ref=e645]:
                    - button "Remove" [ref=e646] [cursor=pointer]
                - row [ref=e647]:
                  - cell [ref=e648]:
                    - spinbutton "Chord radius 39" [ref=e650]: "0.99815"
                  - cell [ref=e651]:
                    - spinbutton "Chord value 39" [ref=e653]: "6.821"
                  - cell [ref=e654]:
                    - button "Remove" [ref=e655] [cursor=pointer]
                - row [ref=e656]:
                  - cell [ref=e657]:
                    - spinbutton "Chord radius 40" [disabled] [ref=e659]: "1"
                  - cell [ref=e660]:
                    - spinbutton "Chord value 40" [ref=e662]: "5.964"
                  - cell [ref=e663]:
                    - button "Remove" [disabled] [ref=e664] [cursor=pointer]
          - generic [ref=e665]:
            - generic [ref=e666]:
              - heading "Twist (40)" [level=3] [ref=e667]
              - button "Add Control Point" [ref=e668] [cursor=pointer]
            - generic [ref=e669]:
              - text: Interpolation
              - combobox "Twist interpolation" [ref=e670]:
                - option "Linear"
                - option "PCHIP" [selected]
            - table [ref=e672]:
              - rowgroup [ref=e673]:
                - row [ref=e674]:
                  - columnheader "r/R" [ref=e675]
                  - columnheader "Twist (deg)" [ref=e676]
                  - columnheader [ref=e677]
              - rowgroup [ref=e678]:
                - row [ref=e679]:
                  - cell [ref=e680]:
                    - spinbutton "Twist radius 1" [disabled] [ref=e682]: "0.20238"
                  - cell [ref=e683]:
                    - spinbutton "Twist value 1" [ref=e685]: "69.838"
                  - cell [ref=e686]:
                    - button "Remove" [disabled] [ref=e687] [cursor=pointer]
                - row [ref=e688]:
                  - cell [ref=e689]:
                    - spinbutton "Twist radius 2" [ref=e691]: "0.20949"
                  - cell [ref=e692]:
                    - spinbutton "Twist value 2" [ref=e694]: "68.892"
                  - cell [ref=e695]:
                    - button "Remove" [ref=e696] [cursor=pointer]
                - row [ref=e697]:
                  - cell [ref=e698]:
                    - spinbutton "Twist radius 3" [ref=e700]: "0.22302"
                  - cell [ref=e701]:
                    - spinbutton "Twist value 3" [ref=e703]: "67.101"
                  - cell [ref=e704]:
                    - button "Remove" [ref=e705] [cursor=pointer]
                - row [ref=e706]:
                  - cell [ref=e707]:
                    - spinbutton "Twist radius 4" [ref=e709]: "0.24183"
                  - cell [ref=e710]:
                    - spinbutton "Twist value 4" [ref=e712]: "64.648"
                  - cell [ref=e713]:
                    - button "Remove" [ref=e714] [cursor=pointer]
                - row [ref=e715]:
                  - cell [ref=e716]:
                    - spinbutton "Twist radius 5" [ref=e718]: "0.26472"
                  - cell [ref=e719]:
                    - spinbutton "Twist value 5" [ref=e721]: "61.758"
                  - cell [ref=e722]:
                    - button "Remove" [ref=e723] [cursor=pointer]
                - row [ref=e724]:
                  - cell [ref=e725]:
                    - spinbutton "Twist radius 6" [ref=e727]: "0.29061"
                  - cell [ref=e728]:
                    - spinbutton "Twist value 6" [ref=e730]: "58.582"
                  - cell [ref=e731]:
                    - button "Remove" [ref=e732] [cursor=pointer]
                - row [ref=e733]:
                  - cell [ref=e734]:
                    - spinbutton "Twist radius 7" [ref=e736]: "0.31863"
                  - cell [ref=e737]:
                    - spinbutton "Twist value 7" [ref=e739]: "55.211"
                  - cell [ref=e740]:
                    - button "Remove" [ref=e741] [cursor=pointer]
                - row [ref=e742]:
                  - cell [ref=e743]:
                    - spinbutton "Twist radius 8" [ref=e745]: "0.34811"
                  - cell [ref=e746]:
                    - spinbutton "Twist value 8" [ref=e748]: "51.651"
                  - cell [ref=e749]:
                    - button "Remove" [ref=e750] [cursor=pointer]
                - row [ref=e751]:
                  - cell [ref=e752]:
                    - spinbutton "Twist radius 9" [ref=e754]: "0.37855"
                  - cell [ref=e755]:
                    - spinbutton "Twist value 9" [ref=e757]: "48.04"
                  - cell [ref=e758]:
                    - button "Remove" [ref=e759] [cursor=pointer]
                - row [ref=e760]:
                  - cell [ref=e761]:
                    - spinbutton "Twist radius 10" [ref=e763]: "0.40957"
                  - cell [ref=e764]:
                    - spinbutton "Twist value 10" [ref=e766]: "44.752"
                  - cell [ref=e767]:
                    - button "Remove" [ref=e768] [cursor=pointer]
                - row [ref=e769]:
                  - cell [ref=e770]:
                    - spinbutton "Twist radius 11" [ref=e772]: "0.44087"
                  - cell [ref=e773]:
                    - spinbutton "Twist value 11" [ref=e775]: "41.977"
                  - cell [ref=e776]:
                    - button "Remove" [ref=e777] [cursor=pointer]
                - row [ref=e778]:
                  - cell [ref=e779]:
                    - spinbutton "Twist radius 12" [ref=e781]: "0.47223"
                  - cell [ref=e782]:
                    - spinbutton "Twist value 12" [ref=e784]: "39.596"
                  - cell [ref=e785]:
                    - button "Remove" [ref=e786] [cursor=pointer]
                - row [ref=e787]:
                  - cell [ref=e788]:
                    - spinbutton "Twist radius 13" [ref=e790]: "0.50345"
                  - cell [ref=e791]:
                    - spinbutton "Twist value 13" [ref=e793]: "37.492"
                  - cell [ref=e794]:
                    - button "Remove" [ref=e795] [cursor=pointer]
                - row [ref=e796]:
                  - cell [ref=e797]:
                    - spinbutton "Twist radius 14" [ref=e799]: "0.53439"
                  - cell [ref=e800]:
                    - spinbutton "Twist value 14" [ref=e802]: "35.647"
                  - cell [ref=e803]:
                    - button "Remove" [ref=e804] [cursor=pointer]
                - row [ref=e805]:
                  - cell [ref=e806]:
                    - spinbutton "Twist radius 15" [ref=e808]: "0.56491"
                  - cell [ref=e809]:
                    - spinbutton "Twist value 15" [ref=e811]: "34.078"
                  - cell [ref=e812]:
                    - button "Remove" [ref=e813] [cursor=pointer]
                - row [ref=e814]:
                  - cell [ref=e815]:
                    - spinbutton "Twist radius 16" [ref=e817]: "0.59491"
                  - cell [ref=e818]:
                    - spinbutton "Twist value 16" [ref=e820]: "32.679"
                  - cell [ref=e821]:
                    - button "Remove" [ref=e822] [cursor=pointer]
                - row [ref=e823]:
                  - cell [ref=e824]:
                    - spinbutton "Twist radius 17" [ref=e826]: "0.62429"
                  - cell [ref=e827]:
                    - spinbutton "Twist value 17" [ref=e829]: "31.435"
                  - cell [ref=e830]:
                    - button "Remove" [ref=e831] [cursor=pointer]
                - row [ref=e832]:
                  - cell [ref=e833]:
                    - spinbutton "Twist radius 18" [ref=e835]: "0.65296"
                  - cell [ref=e836]:
                    - spinbutton "Twist value 18" [ref=e838]: "30.35"
                  - cell [ref=e839]:
                    - button "Remove" [ref=e840] [cursor=pointer]
                - row [ref=e841]:
                  - cell [ref=e842]:
                    - spinbutton "Twist radius 19" [ref=e844]: "0.68085"
                  - cell [ref=e845]:
                    - spinbutton "Twist value 19" [ref=e847]: "29.386"
                  - cell [ref=e848]:
                    - button "Remove" [ref=e849] [cursor=pointer]
                - row [ref=e850]:
                  - cell [ref=e851]:
                    - spinbutton "Twist radius 20" [ref=e853]: "0.70789"
                  - cell [ref=e854]:
                    - spinbutton "Twist value 20" [ref=e856]: "28.526"
                  - cell [ref=e857]:
                    - button "Remove" [ref=e858] [cursor=pointer]
                - row [ref=e859]:
                  - cell [ref=e860]:
                    - spinbutton "Twist radius 21" [ref=e862]: "0.73401"
                  - cell [ref=e863]:
                    - spinbutton "Twist value 21" [ref=e865]: "27.776"
                  - cell [ref=e866]:
                    - button "Remove" [ref=e867] [cursor=pointer]
                - row [ref=e868]:
                  - cell [ref=e869]:
                    - spinbutton "Twist radius 22" [ref=e871]: "0.75916"
                  - cell [ref=e872]:
                    - spinbutton "Twist value 22" [ref=e874]: "27.118"
                  - cell [ref=e875]:
                    - button "Remove" [ref=e876] [cursor=pointer]
                - row [ref=e877]:
                  - cell [ref=e878]:
                    - spinbutton "Twist radius 23" [ref=e880]: "0.78328"
                  - cell [ref=e881]:
                    - spinbutton "Twist value 23" [ref=e883]: "26.541"
                  - cell [ref=e884]:
                    - button "Remove" [ref=e885] [cursor=pointer]
                - row [ref=e886]:
                  - cell [ref=e887]:
                    - spinbutton "Twist radius 24" [ref=e889]: "0.80632"
                  - cell [ref=e890]:
                    - spinbutton "Twist value 24" [ref=e892]: "26.048"
                  - cell [ref=e893]:
                    - button "Remove" [ref=e894] [cursor=pointer]
                - row [ref=e895]:
                  - cell [ref=e896]:
                    - spinbutton "Twist radius 25" [ref=e898]: "0.82823"
                  - cell [ref=e899]:
                    - spinbutton "Twist value 25" [ref=e901]: "25.64"
                  - cell [ref=e902]:
                    - button "Remove" [ref=e903] [cursor=pointer]
                - row [ref=e904]:
                  - cell [ref=e905]:
                    - spinbutton "Twist radius 26" [ref=e907]: "0.84898"
                  - cell [ref=e908]:
                    - spinbutton "Twist value 26" [ref=e910]: "25.294"
                  - cell [ref=e911]:
                    - button "Remove" [ref=e912] [cursor=pointer]
                - row [ref=e913]:
                  - cell [ref=e914]:
                    - spinbutton "Twist radius 27" [ref=e916]: "0.86852"
                  - cell [ref=e917]:
                    - spinbutton "Twist value 27" [ref=e919]: "25.024"
                  - cell [ref=e920]:
                    - button "Remove" [ref=e921] [cursor=pointer]
                - row [ref=e922]:
                  - cell [ref=e923]:
                    - spinbutton "Twist radius 28" [ref=e925]: "0.88681"
                  - cell [ref=e926]:
                    - spinbutton "Twist value 28" [ref=e928]: "24.849"
                  - cell [ref=e929]:
                    - button "Remove" [ref=e930] [cursor=pointer]
                - row [ref=e931]:
                  - cell [ref=e932]:
                    - spinbutton "Twist radius 29" [ref=e934]: "0.90383"
                  - cell [ref=e935]:
                    - spinbutton "Twist value 29" [ref=e937]: "24.765"
                  - cell [ref=e938]:
                    - button "Remove" [ref=e939] [cursor=pointer]
                - row [ref=e940]:
                  - cell [ref=e941]:
                    - spinbutton "Twist radius 30" [ref=e943]: "0.91954"
                  - cell [ref=e944]:
                    - spinbutton "Twist value 30" [ref=e946]: "24.748"
                  - cell [ref=e947]:
                    - button "Remove" [ref=e948] [cursor=pointer]
                - row [ref=e949]:
                  - cell [ref=e950]:
                    - spinbutton "Twist radius 31" [ref=e952]: "0.93391"
                  - cell [ref=e953]:
                    - spinbutton "Twist value 31" [ref=e955]: "24.733"
                  - cell [ref=e956]:
                    - button "Remove" [ref=e957] [cursor=pointer]
                - row [ref=e958]:
                  - cell [ref=e959]:
                    - spinbutton "Twist radius 32" [ref=e961]: "0.94691"
                  - cell [ref=e962]:
                    - spinbutton "Twist value 32" [ref=e964]: "24.696"
                  - cell [ref=e965]:
                    - button "Remove" [ref=e966] [cursor=pointer]
                - row [ref=e967]:
                  - cell [ref=e968]:
                    - spinbutton "Twist radius 33" [ref=e970]: "0.95853"
                  - cell [ref=e971]:
                    - spinbutton "Twist value 33" [ref=e973]: "24.674"
                  - cell [ref=e974]:
                    - button "Remove" [ref=e975] [cursor=pointer]
                - row [ref=e976]:
                  - cell [ref=e977]:
                    - spinbutton "Twist radius 34" [ref=e979]: "0.96874"
                  - cell [ref=e980]:
                    - spinbutton "Twist value 34" [ref=e982]: "24.694"
                  - cell [ref=e983]:
                    - button "Remove" [ref=e984] [cursor=pointer]
                - row [ref=e985]:
                  - cell [ref=e986]:
                    - spinbutton "Twist radius 35" [ref=e988]: "0.97753"
                  - cell [ref=e989]:
                    - spinbutton "Twist value 35" [ref=e991]: "24.751"
                  - cell [ref=e992]:
                    - button "Remove" [ref=e993] [cursor=pointer]
                - row [ref=e994]:
                  - cell [ref=e995]:
                    - spinbutton "Twist radius 36" [ref=e997]: "0.98488"
                  - cell [ref=e998]:
                    - spinbutton "Twist value 36" [ref=e1000]: "24.821"
                  - cell [ref=e1001]:
                    - button "Remove" [ref=e1002] [cursor=pointer]
                - row [ref=e1003]:
                  - cell [ref=e1004]:
                    - spinbutton "Twist radius 37" [ref=e1006]: "0.99077"
                  - cell [ref=e1007]:
                    - spinbutton "Twist value 37" [ref=e1009]: "24.887"
                  - cell [ref=e1010]:
                    - button "Remove" [ref=e1011] [cursor=pointer]
                - row [ref=e1012]:
                  - cell [ref=e1013]:
                    - spinbutton "Twist radius 38" [ref=e1015]: "0.99519"
                  - cell [ref=e1016]:
                    - spinbutton "Twist value 38" [ref=e1018]: "24.94"
                  - cell [ref=e1019]:
                    - button "Remove" [ref=e1020] [cursor=pointer]
                - row [ref=e1021]:
                  - cell [ref=e1022]:
                    - spinbutton "Twist radius 39" [ref=e1024]: "0.99815"
                  - cell [ref=e1025]:
                    - spinbutton "Twist value 39" [ref=e1027]: "24.977"
                  - cell [ref=e1028]:
                    - button "Remove" [ref=e1029] [cursor=pointer]
                - row [ref=e1030]:
                  - cell [ref=e1031]:
                    - spinbutton "Twist radius 40" [disabled] [ref=e1033]: "1"
                  - cell [ref=e1034]:
                    - spinbutton "Twist value 40" [ref=e1036]: "24.995"
                  - cell [ref=e1037]:
                    - button "Remove" [disabled] [ref=e1038] [cursor=pointer]
          - generic [ref=e1039]:
            - generic [ref=e1040]:
              - heading "Rake (40)" [level=3] [ref=e1041]
              - button "Add Control Point" [ref=e1042] [cursor=pointer]
            - generic [ref=e1043]:
              - text: Interpolation
              - combobox "Rake interpolation" [ref=e1044]:
                - option "Linear"
                - option "PCHIP" [selected]
            - table [ref=e1046]:
              - rowgroup [ref=e1047]:
                - row [ref=e1048]:
                  - columnheader "r/R" [ref=e1049]
                  - columnheader "Rake (mm)" [ref=e1050]
                  - columnheader [ref=e1051]
              - rowgroup [ref=e1052]:
                - row [ref=e1053]:
                  - cell [ref=e1054]:
                    - spinbutton "Rake radius 1" [disabled] [ref=e1056]: "0.20238"
                  - cell [ref=e1057]:
                    - spinbutton "Rake value 1" [ref=e1059]: "-15.475"
                  - cell [ref=e1060]:
                    - button "Remove" [disabled] [ref=e1061] [cursor=pointer]
                - row [ref=e1062]:
                  - cell [ref=e1063]:
                    - spinbutton "Rake radius 2" [ref=e1065]: "0.20949"
                  - cell [ref=e1066]:
                    - spinbutton "Rake value 2" [ref=e1068]: "-14.844"
                  - cell [ref=e1069]:
                    - button "Remove" [ref=e1070] [cursor=pointer]
                - row [ref=e1071]:
                  - cell [ref=e1072]:
                    - spinbutton "Rake radius 3" [ref=e1074]: "0.22302"
                  - cell [ref=e1075]:
                    - spinbutton "Rake value 3" [ref=e1077]: "-13.604"
                  - cell [ref=e1078]:
                    - button "Remove" [ref=e1079] [cursor=pointer]
                - row [ref=e1080]:
                  - cell [ref=e1081]:
                    - spinbutton "Rake radius 4" [ref=e1083]: "0.24183"
                  - cell [ref=e1084]:
                    - spinbutton "Rake value 4" [ref=e1086]: "-12.169"
                  - cell [ref=e1087]:
                    - button "Remove" [ref=e1088] [cursor=pointer]
                - row [ref=e1089]:
                  - cell [ref=e1090]:
                    - spinbutton "Rake radius 5" [ref=e1092]: "0.26472"
                  - cell [ref=e1093]:
                    - spinbutton "Rake value 5" [ref=e1095]: "-11.062"
                  - cell [ref=e1096]:
                    - button "Remove" [ref=e1097] [cursor=pointer]
                - row [ref=e1098]:
                  - cell [ref=e1099]:
                    - spinbutton "Rake radius 6" [ref=e1101]: "0.29061"
                  - cell [ref=e1102]:
                    - spinbutton "Rake value 6" [ref=e1104]: "-10.643"
                  - cell [ref=e1105]:
                    - button "Remove" [ref=e1106] [cursor=pointer]
                - row [ref=e1107]:
                  - cell [ref=e1108]:
                    - spinbutton "Rake radius 7" [ref=e1110]: "0.31863"
                  - cell [ref=e1111]:
                    - spinbutton "Rake value 7" [ref=e1113]: "-11.119"
                  - cell [ref=e1114]:
                    - button "Remove" [ref=e1115] [cursor=pointer]
                - row [ref=e1116]:
                  - cell [ref=e1117]:
                    - spinbutton "Rake radius 8" [ref=e1119]: "0.34811"
                  - cell [ref=e1120]:
                    - spinbutton "Rake value 8" [ref=e1122]: "-12.27"
                  - cell [ref=e1123]:
                    - button "Remove" [ref=e1124] [cursor=pointer]
                - row [ref=e1125]:
                  - cell [ref=e1126]:
                    - spinbutton "Rake radius 9" [ref=e1128]: "0.37855"
                  - cell [ref=e1129]:
                    - spinbutton "Rake value 9" [ref=e1131]: "-13.524"
                  - cell [ref=e1132]:
                    - button "Remove" [ref=e1133] [cursor=pointer]
                - row [ref=e1134]:
                  - cell [ref=e1135]:
                    - spinbutton "Rake radius 10" [ref=e1137]: "0.40957"
                  - cell [ref=e1138]:
                    - spinbutton "Rake value 10" [ref=e1140]: "-14.402"
                  - cell [ref=e1141]:
                    - button "Remove" [ref=e1142] [cursor=pointer]
                - row [ref=e1143]:
                  - cell [ref=e1144]:
                    - spinbutton "Rake radius 11" [ref=e1146]: "0.44087"
                  - cell [ref=e1147]:
                    - spinbutton "Rake value 11" [ref=e1149]: "-14.628"
                  - cell [ref=e1150]:
                    - button "Remove" [ref=e1151] [cursor=pointer]
                - row [ref=e1152]:
                  - cell [ref=e1153]:
                    - spinbutton "Rake radius 12" [ref=e1155]: "0.47223"
                  - cell [ref=e1156]:
                    - spinbutton "Rake value 12" [ref=e1158]: "-14.465"
                  - cell [ref=e1159]:
                    - button "Remove" [ref=e1160] [cursor=pointer]
                - row [ref=e1161]:
                  - cell [ref=e1162]:
                    - spinbutton "Rake radius 13" [ref=e1164]: "0.50345"
                  - cell [ref=e1165]:
                    - spinbutton "Rake value 13" [ref=e1167]: "-14.405"
                  - cell [ref=e1168]:
                    - button "Remove" [ref=e1169] [cursor=pointer]
                - row [ref=e1170]:
                  - cell [ref=e1171]:
                    - spinbutton "Rake radius 14" [ref=e1173]: "0.53439"
                  - cell [ref=e1174]:
                    - spinbutton "Rake value 14" [ref=e1176]: "-14.426"
                  - cell [ref=e1177]:
                    - button "Remove" [ref=e1178] [cursor=pointer]
                - row [ref=e1179]:
                  - cell [ref=e1180]:
                    - spinbutton "Rake radius 15" [ref=e1182]: "0.56491"
                  - cell [ref=e1183]:
                    - spinbutton "Rake value 15" [ref=e1185]: "-14.499"
                  - cell [ref=e1186]:
                    - button "Remove" [ref=e1187] [cursor=pointer]
                - row [ref=e1188]:
                  - cell [ref=e1189]:
                    - spinbutton "Rake radius 16" [ref=e1191]: "0.59491"
                  - cell [ref=e1192]:
                    - spinbutton "Rake value 16" [ref=e1194]: "-14.606"
                  - cell [ref=e1195]:
                    - button "Remove" [ref=e1196] [cursor=pointer]
                - row [ref=e1197]:
                  - cell [ref=e1198]:
                    - spinbutton "Rake radius 17" [ref=e1200]: "0.62429"
                  - cell [ref=e1201]:
                    - spinbutton "Rake value 17" [ref=e1203]: "-14.734"
                  - cell [ref=e1204]:
                    - button "Remove" [ref=e1205] [cursor=pointer]
                - row [ref=e1206]:
                  - cell [ref=e1207]:
                    - spinbutton "Rake radius 18" [ref=e1209]: "0.65296"
                  - cell [ref=e1210]:
                    - spinbutton "Rake value 18" [ref=e1212]: "-14.872"
                  - cell [ref=e1213]:
                    - button "Remove" [ref=e1214] [cursor=pointer]
                - row [ref=e1215]:
                  - cell [ref=e1216]:
                    - spinbutton "Rake radius 19" [ref=e1218]: "0.68085"
                  - cell [ref=e1219]:
                    - spinbutton "Rake value 19" [ref=e1221]: "-15.015"
                  - cell [ref=e1222]:
                    - button "Remove" [ref=e1223] [cursor=pointer]
                - row [ref=e1224]:
                  - cell [ref=e1225]:
                    - spinbutton "Rake radius 20" [ref=e1227]: "0.70789"
                  - cell [ref=e1228]:
                    - spinbutton "Rake value 20" [ref=e1230]: "-15.158"
                  - cell [ref=e1231]:
                    - button "Remove" [ref=e1232] [cursor=pointer]
                - row [ref=e1233]:
                  - cell [ref=e1234]:
                    - spinbutton "Rake radius 21" [ref=e1236]: "0.73401"
                  - cell [ref=e1237]:
                    - spinbutton "Rake value 21" [ref=e1239]: "-15.295"
                  - cell [ref=e1240]:
                    - button "Remove" [ref=e1241] [cursor=pointer]
                - row [ref=e1242]:
                  - cell [ref=e1243]:
                    - spinbutton "Rake radius 22" [ref=e1245]: "0.75916"
                  - cell [ref=e1246]:
                    - spinbutton "Rake value 22" [ref=e1248]: "-15.425"
                  - cell [ref=e1249]:
                    - button "Remove" [ref=e1250] [cursor=pointer]
                - row [ref=e1251]:
                  - cell [ref=e1252]:
                    - spinbutton "Rake radius 23" [ref=e1254]: "0.78328"
                  - cell [ref=e1255]:
                    - spinbutton "Rake value 23" [ref=e1257]: "-15.545"
                  - cell [ref=e1258]:
                    - button "Remove" [ref=e1259] [cursor=pointer]
                - row [ref=e1260]:
                  - cell [ref=e1261]:
                    - spinbutton "Rake radius 24" [ref=e1263]: "0.80632"
                  - cell [ref=e1264]:
                    - spinbutton "Rake value 24" [ref=e1266]: "-15.654"
                  - cell [ref=e1267]:
                    - button "Remove" [ref=e1268] [cursor=pointer]
                - row [ref=e1269]:
                  - cell [ref=e1270]:
                    - spinbutton "Rake radius 25" [ref=e1272]: "0.82823"
                  - cell [ref=e1273]:
                    - spinbutton "Rake value 25" [ref=e1275]: "-15.747"
                  - cell [ref=e1276]:
                    - button "Remove" [ref=e1277] [cursor=pointer]
                - row [ref=e1278]:
                  - cell [ref=e1279]:
                    - spinbutton "Rake radius 26" [ref=e1281]: "0.84898"
                  - cell [ref=e1282]:
                    - spinbutton "Rake value 26" [ref=e1284]: "-15.83"
                  - cell [ref=e1285]:
                    - button "Remove" [ref=e1286] [cursor=pointer]
                - row [ref=e1287]:
                  - cell [ref=e1288]:
                    - spinbutton "Rake radius 27" [ref=e1290]: "0.86852"
                  - cell [ref=e1291]:
                    - spinbutton "Rake value 27" [ref=e1293]: "-15.895"
                  - cell [ref=e1294]:
                    - button "Remove" [ref=e1295] [cursor=pointer]
                - row [ref=e1296]:
                  - cell [ref=e1297]:
                    - spinbutton "Rake radius 28" [ref=e1299]: "0.88681"
                  - cell [ref=e1300]:
                    - spinbutton "Rake value 28" [ref=e1302]: "-15.939"
                  - cell [ref=e1303]:
                    - button "Remove" [ref=e1304] [cursor=pointer]
                - row [ref=e1305]:
                  - cell [ref=e1306]:
                    - spinbutton "Rake radius 29" [ref=e1308]: "0.90383"
                  - cell [ref=e1309]:
                    - spinbutton "Rake value 29" [ref=e1311]: "-15.96"
                  - cell [ref=e1312]:
                    - button "Remove" [ref=e1313] [cursor=pointer]
                - row [ref=e1314]:
                  - cell [ref=e1315]:
                    - spinbutton "Rake radius 30" [ref=e1317]: "0.91954"
                  - cell [ref=e1318]:
                    - spinbutton "Rake value 30" [ref=e1320]: "-15.965"
                  - cell [ref=e1321]:
                    - button "Remove" [ref=e1322] [cursor=pointer]
                - row [ref=e1323]:
                  - cell [ref=e1324]:
                    - spinbutton "Rake radius 31" [ref=e1326]: "0.93391"
                  - cell [ref=e1327]:
                    - spinbutton "Rake value 31" [ref=e1329]: "-15.969"
                  - cell [ref=e1330]:
                    - button "Remove" [ref=e1331] [cursor=pointer]
                - row [ref=e1332]:
                  - cell [ref=e1333]:
                    - spinbutton "Rake radius 32" [ref=e1335]: "0.94691"
                  - cell [ref=e1336]:
                    - spinbutton "Rake value 32" [ref=e1338]: "-15.979"
                  - cell [ref=e1339]:
                    - button "Remove" [ref=e1340] [cursor=pointer]
                - row [ref=e1341]:
                  - cell [ref=e1342]:
                    - spinbutton "Rake radius 33" [ref=e1344]: "0.95853"
                  - cell [ref=e1345]:
                    - spinbutton "Rake value 33" [ref=e1347]: "-15.986"
                  - cell [ref=e1348]:
                    - button "Remove" [ref=e1349] [cursor=pointer]
                - row [ref=e1350]:
                  - cell [ref=e1351]:
                    - spinbutton "Rake radius 34" [ref=e1353]: "0.96874"
                  - cell [ref=e1354]:
                    - spinbutton "Rake value 34" [ref=e1356]: "-15.983"
                  - cell [ref=e1357]:
                    - button "Remove" [ref=e1358] [cursor=pointer]
                - row [ref=e1359]:
                  - cell [ref=e1360]:
                    - spinbutton "Rake radius 35" [ref=e1362]: "0.97753"
                  - cell [ref=e1363]:
                    - spinbutton "Rake value 35" [ref=e1365]: "-15.971"
                  - cell [ref=e1366]:
                    - button "Remove" [ref=e1367] [cursor=pointer]
                - row [ref=e1368]:
                  - cell [ref=e1369]:
                    - spinbutton "Rake radius 36" [ref=e1371]: "0.98488"
                  - cell [ref=e1372]:
                    - spinbutton "Rake value 36" [ref=e1374]: "-15.956"
                  - cell [ref=e1375]:
                    - button "Remove" [ref=e1376] [cursor=pointer]
                - row [ref=e1377]:
                  - cell [ref=e1378]:
                    - spinbutton "Rake radius 37" [ref=e1380]: "0.99077"
                  - cell [ref=e1381]:
                    - spinbutton "Rake value 37" [ref=e1383]: "-15.942"
                  - cell [ref=e1384]:
                    - button "Remove" [ref=e1385] [cursor=pointer]
                - row [ref=e1386]:
                  - cell [ref=e1387]:
                    - spinbutton "Rake radius 38" [ref=e1389]: "0.99519"
                  - cell [ref=e1390]:
                    - spinbutton "Rake value 38" [ref=e1392]: "-15.93"
                  - cell [ref=e1393]:
                    - button "Remove" [ref=e1394] [cursor=pointer]
                - row [ref=e1395]:
                  - cell [ref=e1396]:
                    - spinbutton "Rake radius 39" [ref=e1398]: "0.99815"
                  - cell [ref=e1399]:
                    - spinbutton "Rake value 39" [ref=e1401]: "-15.923"
                  - cell [ref=e1402]:
                    - button "Remove" [ref=e1403] [cursor=pointer]
                - row [ref=e1404]:
                  - cell [ref=e1405]:
                    - spinbutton "Rake radius 40" [disabled] [ref=e1407]: "1"
                  - cell [ref=e1408]:
                    - spinbutton "Rake value 40" [ref=e1410]: "-15.919"
                  - cell [ref=e1411]:
                    - button "Remove" [disabled] [ref=e1412] [cursor=pointer]
          - generic [ref=e1413]:
            - generic [ref=e1414]:
              - heading "Skew (40)" [level=3] [ref=e1415]
              - button "Add Control Point" [ref=e1416] [cursor=pointer]
            - generic [ref=e1417]:
              - text: Interpolation
              - combobox "Skew interpolation" [ref=e1418]:
                - option "Linear"
                - option "PCHIP" [selected]
            - table [ref=e1420]:
              - rowgroup [ref=e1421]:
                - row [ref=e1422]:
                  - columnheader "r/R" [ref=e1423]
                  - columnheader "Skew (mm)" [ref=e1424]
                  - columnheader [ref=e1425]
              - rowgroup [ref=e1426]:
                - row [ref=e1427]:
                  - cell [ref=e1428]:
                    - spinbutton "Skew radius 1" [disabled] [ref=e1430]: "0.20238"
                  - cell [ref=e1431]:
                    - spinbutton "Skew value 1" [ref=e1433]: "36.295"
                  - cell [ref=e1434]:
                    - button "Remove" [disabled] [ref=e1435] [cursor=pointer]
                - row [ref=e1436]:
                  - cell [ref=e1437]:
                    - spinbutton "Skew radius 2" [ref=e1439]: "0.20949"
                  - cell [ref=e1440]:
                    - spinbutton "Skew value 2" [ref=e1442]: "35.359"
                  - cell [ref=e1443]:
                    - button "Remove" [ref=e1444] [cursor=pointer]
                - row [ref=e1445]:
                  - cell [ref=e1446]:
                    - spinbutton "Skew radius 3" [ref=e1448]: "0.22302"
                  - cell [ref=e1449]:
                    - spinbutton "Skew value 3" [ref=e1451]: "33.561"
                  - cell [ref=e1452]:
                    - button "Remove" [ref=e1453] [cursor=pointer]
                - row [ref=e1454]:
                  - cell [ref=e1455]:
                    - spinbutton "Skew radius 4" [ref=e1457]: "0.24183"
                  - cell [ref=e1458]:
                    - spinbutton "Skew value 4" [ref=e1460]: "31.046"
                  - cell [ref=e1461]:
                    - button "Remove" [ref=e1462] [cursor=pointer]
                - row [ref=e1463]:
                  - cell [ref=e1464]:
                    - spinbutton "Skew radius 5" [ref=e1466]: "0.26472"
                  - cell [ref=e1467]:
                    - spinbutton "Skew value 5" [ref=e1469]: "28.01"
                  - cell [ref=e1470]:
                    - button "Remove" [ref=e1471] [cursor=pointer]
                - row [ref=e1472]:
                  - cell [ref=e1473]:
                    - spinbutton "Skew radius 6" [ref=e1475]: "0.29061"
                  - cell [ref=e1476]:
                    - spinbutton "Skew value 6" [ref=e1478]: "24.591"
                  - cell [ref=e1479]:
                    - button "Remove" [ref=e1480] [cursor=pointer]
                - row [ref=e1481]:
                  - cell [ref=e1482]:
                    - spinbutton "Skew radius 7" [ref=e1484]: "0.31863"
                  - cell [ref=e1485]:
                    - spinbutton "Skew value 7" [ref=e1487]: "20.881"
                  - cell [ref=e1488]:
                    - button "Remove" [ref=e1489] [cursor=pointer]
                - row [ref=e1490]:
                  - cell [ref=e1491]:
                    - spinbutton "Skew radius 8" [ref=e1493]: "0.34811"
                  - cell [ref=e1494]:
                    - spinbutton "Skew value 8" [ref=e1496]: "16.884"
                  - cell [ref=e1497]:
                    - button "Remove" [ref=e1498] [cursor=pointer]
                - row [ref=e1499]:
                  - cell [ref=e1500]:
                    - spinbutton "Skew radius 9" [ref=e1502]: "0.37855"
                  - cell [ref=e1503]:
                    - spinbutton "Skew value 9" [ref=e1505]: "12.763"
                  - cell [ref=e1506]:
                    - button "Remove" [ref=e1507] [cursor=pointer]
                - row [ref=e1508]:
                  - cell [ref=e1509]:
                    - spinbutton "Skew radius 10" [ref=e1511]: "0.40957"
                  - cell [ref=e1512]:
                    - spinbutton "Skew value 10" [ref=e1514]: "8.966"
                  - cell [ref=e1515]:
                    - button "Remove" [ref=e1516] [cursor=pointer]
                - row [ref=e1517]:
                  - cell [ref=e1518]:
                    - spinbutton "Skew radius 11" [ref=e1520]: "0.44087"
                  - cell [ref=e1521]:
                    - spinbutton "Skew value 11" [ref=e1523]: "5.738"
                  - cell [ref=e1524]:
                    - button "Remove" [ref=e1525] [cursor=pointer]
                - row [ref=e1526]:
                  - cell [ref=e1527]:
                    - spinbutton "Skew radius 12" [ref=e1529]: "0.47223"
                  - cell [ref=e1530]:
                    - spinbutton "Skew value 12" [ref=e1532]: "2.958"
                  - cell [ref=e1533]:
                    - button "Remove" [ref=e1534] [cursor=pointer]
                - row [ref=e1535]:
                  - cell [ref=e1536]:
                    - spinbutton "Skew radius 13" [ref=e1538]: "0.50345"
                  - cell [ref=e1539]:
                    - spinbutton "Skew value 13" [ref=e1541]: "0.496"
                  - cell [ref=e1542]:
                    - button "Remove" [ref=e1543] [cursor=pointer]
                - row [ref=e1544]:
                  - cell [ref=e1545]:
                    - spinbutton "Skew radius 14" [ref=e1547]: "0.53439"
                  - cell [ref=e1548]:
                    - spinbutton "Skew value 14" [ref=e1550]: "-1.663"
                  - cell [ref=e1551]:
                    - button "Remove" [ref=e1552] [cursor=pointer]
                - row [ref=e1553]:
                  - cell [ref=e1554]:
                    - spinbutton "Skew radius 15" [ref=e1556]: "0.56491"
                  - cell [ref=e1557]:
                    - spinbutton "Skew value 15" [ref=e1559]: "-3.498"
                  - cell [ref=e1560]:
                    - button "Remove" [ref=e1561] [cursor=pointer]
                - row [ref=e1562]:
                  - cell [ref=e1563]:
                    - spinbutton "Skew radius 16" [ref=e1565]: "0.59491"
                  - cell [ref=e1566]:
                    - spinbutton "Skew value 16" [ref=e1568]: "-5.132"
                  - cell [ref=e1569]:
                    - button "Remove" [ref=e1570] [cursor=pointer]
                - row [ref=e1571]:
                  - cell [ref=e1572]:
                    - spinbutton "Skew radius 17" [ref=e1574]: "0.62429"
                  - cell [ref=e1575]:
                    - spinbutton "Skew value 17" [ref=e1577]: "-6.582"
                  - cell [ref=e1578]:
                    - button "Remove" [ref=e1579] [cursor=pointer]
                - row [ref=e1580]:
                  - cell [ref=e1581]:
                    - spinbutton "Skew radius 18" [ref=e1583]: "0.65296"
                  - cell [ref=e1584]:
                    - spinbutton "Skew value 18" [ref=e1586]: "-7.844"
                  - cell [ref=e1587]:
                    - button "Remove" [ref=e1588] [cursor=pointer]
                - row [ref=e1589]:
                  - cell [ref=e1590]:
                    - spinbutton "Skew radius 19" [ref=e1592]: "0.68085"
                  - cell [ref=e1593]:
                    - spinbutton "Skew value 19" [ref=e1595]: "-8.964"
                  - cell [ref=e1596]:
                    - button "Remove" [ref=e1597] [cursor=pointer]
                - row [ref=e1598]:
                  - cell [ref=e1599]:
                    - spinbutton "Skew radius 20" [ref=e1601]: "0.70789"
                  - cell [ref=e1602]:
                    - spinbutton "Skew value 20" [ref=e1604]: "-9.96"
                  - cell [ref=e1605]:
                    - button "Remove" [ref=e1606] [cursor=pointer]
                - row [ref=e1607]:
                  - cell [ref=e1608]:
                    - spinbutton "Skew radius 21" [ref=e1610]: "0.73401"
                  - cell [ref=e1611]:
                    - spinbutton "Skew value 21" [ref=e1613]: "-10.827"
                  - cell [ref=e1614]:
                    - button "Remove" [ref=e1615] [cursor=pointer]
                - row [ref=e1616]:
                  - cell [ref=e1617]:
                    - spinbutton "Skew radius 22" [ref=e1619]: "0.75916"
                  - cell [ref=e1620]:
                    - spinbutton "Skew value 22" [ref=e1622]: "-11.587"
                  - cell [ref=e1623]:
                    - button "Remove" [ref=e1624] [cursor=pointer]
                - row [ref=e1625]:
                  - cell [ref=e1626]:
                    - spinbutton "Skew radius 23" [ref=e1628]: "0.78328"
                  - cell [ref=e1629]:
                    - spinbutton "Skew value 23" [ref=e1631]: "-12.251"
                  - cell [ref=e1632]:
                    - button "Remove" [ref=e1633] [cursor=pointer]
                - row [ref=e1634]:
                  - cell [ref=e1635]:
                    - spinbutton "Skew radius 24" [ref=e1637]: "0.80632"
                  - cell [ref=e1638]:
                    - spinbutton "Skew value 24" [ref=e1640]: "-12.818"
                  - cell [ref=e1641]:
                    - button "Remove" [ref=e1642] [cursor=pointer]
                - row [ref=e1643]:
                  - cell [ref=e1644]:
                    - spinbutton "Skew radius 25" [ref=e1646]: "0.82823"
                  - cell [ref=e1647]:
                    - spinbutton "Skew value 25" [ref=e1649]: "-13.286"
                  - cell [ref=e1650]:
                    - button "Remove" [ref=e1651] [cursor=pointer]
                - row [ref=e1652]:
                  - cell [ref=e1653]:
                    - spinbutton "Skew radius 26" [ref=e1655]: "0.84898"
                  - cell [ref=e1656]:
                    - spinbutton "Skew value 26" [ref=e1658]: "-13.683"
                  - cell [ref=e1659]:
                    - button "Remove" [ref=e1660] [cursor=pointer]
                - row [ref=e1661]:
                  - cell [ref=e1662]:
                    - spinbutton "Skew radius 27" [ref=e1664]: "0.86852"
                  - cell [ref=e1665]:
                    - spinbutton "Skew value 27" [ref=e1667]: "-13.992"
                  - cell [ref=e1668]:
                    - button "Remove" [ref=e1669] [cursor=pointer]
                - row [ref=e1670]:
                  - cell [ref=e1671]:
                    - spinbutton "Skew radius 28" [ref=e1673]: "0.88681"
                  - cell [ref=e1674]:
                    - spinbutton "Skew value 28" [ref=e1676]: "-14.192"
                  - cell [ref=e1677]:
                    - button "Remove" [ref=e1678] [cursor=pointer]
                - row [ref=e1679]:
                  - cell [ref=e1680]:
                    - spinbutton "Skew radius 29" [ref=e1682]: "0.90383"
                  - cell [ref=e1683]:
                    - spinbutton "Skew value 29" [ref=e1685]: "-14.288"
                  - cell [ref=e1686]:
                    - button "Remove" [ref=e1687] [cursor=pointer]
                - row [ref=e1688]:
                  - cell [ref=e1689]:
                    - spinbutton "Skew radius 30" [ref=e1691]: "0.91954"
                  - cell [ref=e1692]:
                    - spinbutton "Skew value 30" [ref=e1694]: "-14.308"
                  - cell [ref=e1695]:
                    - button "Remove" [ref=e1696] [cursor=pointer]
                - row [ref=e1697]:
                  - cell [ref=e1698]:
                    - spinbutton "Skew radius 31" [ref=e1700]: "0.93391"
                  - cell [ref=e1701]:
                    - spinbutton "Skew value 31" [ref=e1703]: "-14.325"
                  - cell [ref=e1704]:
                    - button "Remove" [ref=e1705] [cursor=pointer]
                - row [ref=e1706]:
                  - cell [ref=e1707]:
                    - spinbutton "Skew radius 32" [ref=e1709]: "0.94691"
                  - cell [ref=e1710]:
                    - spinbutton "Skew value 32" [ref=e1712]: "-14.367"
                  - cell [ref=e1713]:
                    - button "Remove" [ref=e1714] [cursor=pointer]
                - row [ref=e1715]:
                  - cell [ref=e1716]:
                    - spinbutton "Skew radius 33" [ref=e1718]: "0.95853"
                  - cell [ref=e1719]:
                    - spinbutton "Skew value 33" [ref=e1721]: "-14.392"
                  - cell [ref=e1722]:
                    - button "Remove" [ref=e1723] [cursor=pointer]
                - row [ref=e1724]:
                  - cell [ref=e1725]:
                    - spinbutton "Skew radius 34" [ref=e1727]: "0.96874"
                  - cell [ref=e1728]:
                    - spinbutton "Skew value 34" [ref=e1730]: "-14.37"
                  - cell [ref=e1731]:
                    - button "Remove" [ref=e1732] [cursor=pointer]
                - row [ref=e1733]:
                  - cell [ref=e1734]:
                    - spinbutton "Skew radius 35" [ref=e1736]: "0.97753"
                  - cell [ref=e1737]:
                    - spinbutton "Skew value 35" [ref=e1739]: "-14.304"
                  - cell [ref=e1740]:
                    - button "Remove" [ref=e1741] [cursor=pointer]
                - row [ref=e1742]:
                  - cell [ref=e1743]:
                    - spinbutton "Skew radius 36" [ref=e1745]: "0.98488"
                  - cell [ref=e1746]:
                    - spinbutton "Skew value 36" [ref=e1748]: "-14.224"
                  - cell [ref=e1749]:
                    - button "Remove" [ref=e1750] [cursor=pointer]
                - row [ref=e1751]:
                  - cell [ref=e1752]:
                    - spinbutton "Skew radius 37" [ref=e1754]: "0.99077"
                  - cell [ref=e1755]:
                    - spinbutton "Skew value 37" [ref=e1757]: "-14.149"
                  - cell [ref=e1758]:
                    - button "Remove" [ref=e1759] [cursor=pointer]
                - row [ref=e1760]:
                  - cell [ref=e1761]:
                    - spinbutton "Skew radius 38" [ref=e1763]: "0.99519"
                  - cell [ref=e1764]:
                    - spinbutton "Skew value 38" [ref=e1766]: "-14.088"
                  - cell [ref=e1767]:
                    - button "Remove" [ref=e1768] [cursor=pointer]
                - row [ref=e1769]:
                  - cell [ref=e1770]:
                    - spinbutton "Skew radius 39" [ref=e1772]: "0.99815"
                  - cell [ref=e1773]:
                    - spinbutton "Skew value 39" [ref=e1775]: "-14.046"
                  - cell [ref=e1776]:
                    - button "Remove" [ref=e1777] [cursor=pointer]
                - row [ref=e1778]:
                  - cell [ref=e1779]:
                    - spinbutton "Skew radius 40" [disabled] [ref=e1781]: "1"
                  - cell [ref=e1782]:
                    - spinbutton "Skew value 40" [ref=e1784]: "-14.025"
                  - cell [ref=e1785]:
                    - button "Remove" [disabled] [ref=e1786] [cursor=pointer]
          - generic [ref=e1787]:
            - generic [ref=e1788]:
              - heading "Thickness (2)" [level=3] [ref=e1789]
              - button "Add Control Point" [ref=e1790] [cursor=pointer]
            - generic [ref=e1791]:
              - text: Interpolation
              - combobox "Thickness interpolation" [ref=e1792]:
                - option "Linear" [selected]
                - option "PCHIP"
            - table [ref=e1794]:
              - rowgroup [ref=e1795]:
                - row [ref=e1796]:
                  - columnheader "r/R" [ref=e1797]
                  - columnheader "Thickness (% t/c)" [ref=e1798]
                  - columnheader [ref=e1799]
              - rowgroup [ref=e1800]:
                - row [ref=e1801]:
                  - cell [ref=e1802]:
                    - spinbutton "Thickness radius 1" [disabled] [ref=e1804]: "0.20238"
                  - 'cell "13.0553 Locked: this airfoil station uses imported coordinates, so its natural t/c is protected." [ref=e1805]':
                    - spinbutton "Thickness value 1" [disabled] [ref=e1807]: "13.0553"
                    - generic [ref=e1808]: "Locked: this airfoil station uses imported coordinates, so its natural t/c is protected."
                  - cell [ref=e1809]:
                    - button "Remove" [disabled] [ref=e1810] [cursor=pointer]
                - row [ref=e1811]:
                  - cell [ref=e1812]:
                    - spinbutton "Thickness radius 2" [disabled] [ref=e1814]: "1"
                  - 'cell "13.0553 Locked: this airfoil station uses imported coordinates, so its natural t/c is protected." [ref=e1815]':
                    - spinbutton "Thickness value 2" [disabled] [ref=e1817]: "13.0553"
                    - generic [ref=e1818]: "Locked: this airfoil station uses imported coordinates, so its natural t/c is protected."
                  - cell [ref=e1819]:
                    - button "Remove" [disabled] [ref=e1820] [cursor=pointer]
    - complementary [ref=e1821]:
      - heading "Solid preview" [level=2] [ref=e1822]
      - paragraph [ref=e1823]:
        - strong [ref=e1824]: Last successful build — current inputs
        - text: · Preview from completed job e75f81b2 · blade
      - generic [ref=e1825]:
        - generic [ref=e1828]:
          - generic [ref=e1829]:
            - checkbox "Show Station Guides" [checked] [ref=e1830]
            - text: Show Station Guides
          - paragraph [ref=e1831]: Visual radial-location guides derived from the current design; they are not extracted STEP cross-sections.
          - list "Station guide legend" [ref=e1832]:
            - listitem [ref=e1833]:
              - strong [ref=e1834]: Station 1
              - text: ": r/R 0.2024 · Y 58.277 mm"
        - generic [ref=e1835]:
          - generic [ref=e1836]: OCP solid preview
          - generic [ref=e1837]:
            - button "Blade Face View" [pressed] [ref=e1838] [cursor=pointer]
            - button "Blade Edge View" [ref=e1839] [cursor=pointer]
            - button "Isometric View" [ref=e1840] [cursor=pointer]
            - button "Fit to Model" [ref=e1841] [cursor=pointer]
            - button "Expand Viewer" [ref=e1842] [cursor=pointer]
      - heading "STEP topology" [level=2] [ref=e1843]
      - generic [ref=e1844]:
        - term [ref=e1845]: Solid / free edges
        - definition [ref=e1846]: 1 / 0
        - term [ref=e1847]: Closed / BRep valid
        - definition [ref=e1848]: true / true
        - term [ref=e1849]: Adaptive volume
        - definition [ref=e1850]: 46373.243510 mm³
      - heading "Independent geometry" [level=2] [ref=e1851]
      - generic [ref=e1852]:
        - term [ref=e1853]: Overall
        - definition [ref=e1854]: PASS
        - term [ref=e1855]: Chord / twist max
        - definition [ref=e1856]: 0.00167 mm / 0.03153°
        - term [ref=e1857]: Axis / TE max
        - definition [ref=e1858]: 0.02002 / 0.00000 mm
        - term [ref=e1859]: Contour RMS / P95 / max
        - definition [ref=e1860]: 0.00568 / 0.00941 / 0.01066 mm
        - term [ref=e1861]: Root requested / sampled
        - definition [ref=e1862]: 0.20238 / 0.207365125
        - term [ref=e1863]: Tip requested / sampled
        - definition [ref=e1864]: 1 / 0.9995014875
      - group [ref=e1865]:
        - generic "Per-station measurements (41)" [ref=e1866]
      - heading "Artifacts" [level=2] [ref=e1867]
      - paragraph [ref=e1868]: Artifacts from completed job e75f81b2
      - list [ref=e1869]:
        - listitem [ref=e1870]:
          - link "blade_openvsp.step" [ref=e1871] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/blade_openvsp.step
          - generic [ref=e1872]: 82892 KB
        - listitem [ref=e1873]:
          - link "blade_openvsp.vsp3" [ref=e1874] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/blade_openvsp.vsp3
          - generic [ref=e1875]: 213 KB
        - listitem [ref=e1876]:
          - link "blade_preview.stl" [ref=e1877] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/blade_preview.stl
          - generic [ref=e1878]: 23194 KB
        - listitem [ref=e1879]:
          - link "blade_solid.step" [ref=e1880] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/blade_solid.step
          - generic [ref=e1881]: 84030 KB
        - listitem [ref=e1882]:
          - link "blade_spec.json" [ref=e1883] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/blade_spec.json
          - generic [ref=e1884]: 40 KB
        - listitem [ref=e1885]:
          - link "engine_manifest.json" [ref=e1886] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/engine_manifest.json
          - generic [ref=e1887]: 12 KB
        - listitem [ref=e1888]:
          - link "resolved_blade_spec.json" [ref=e1889] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/resolved_blade_spec.json
          - generic [ref=e1890]: 92 KB
        - listitem [ref=e1891]:
          - link "validation.csv" [ref=e1892] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/validation.csv
          - generic [ref=e1893]: 1 KB
        - listitem [ref=e1894]:
          - link "validation.json" [ref=e1895] [cursor=pointer]:
            - /url: /api/jobs/e75f81b293d44d2494e52f0e4b40ae3f/artifacts/validation.json
          - generic [ref=e1896]: 98 KB
```

# Test source

```ts
  370 |   expect(download.suggestedFilename()).toBe('X57_HLP_manual_test.json')
  371 |   const exportedCandidatePath = path.join(evidenceRoot, 'exported_candidate.json')
  372 |   await download.saveAs(exportedCandidatePath)
  373 |   const exportedCandidate = JSON.parse(await readFile(exportedCandidatePath, 'utf8')) as BladeSpec
  374 |   const inputFidelity = verifyX57ExportedCandidate(exportedCandidate, fixture)
  375 | 
  376 |   const jobId = await submitBuild(page, 'Generate Blade', '/api/build')
  377 |   expect(buildRequests).toBe(buildRequestsBeforeApplyQualification + 1)
  378 |   const terminalJob = await waitForTerminalJob(page, jobId)
  379 |   const jobEvidenceRoot = path.join(evidenceRoot, 'job')
  380 |   await mkdir(jobEvidenceRoot, { recursive: true })
  381 |   const sourceJobRoot = path.join(runRoot, jobId)
  382 |   const retained = (await Promise.all([
  383 |     copyIfPresent(path.join(sourceJobRoot, 'blade_spec_input.json'), path.join(jobEvidenceRoot, 'submitted_blade_spec.json')),
  384 |     copyIfPresent(path.join(sourceJobRoot, 'blade_spec.json'), path.join(jobEvidenceRoot, 'blade_spec.json')),
  385 |     copyIfPresent(path.join(sourceJobRoot, 'validation.json'), path.join(jobEvidenceRoot, 'validation.json')),
  386 |     copyIfPresent(path.join(sourceJobRoot, 'engine_manifest.json'), path.join(jobEvidenceRoot, 'engine_manifest.json')),
  387 |     copyIfPresent(path.join(sourceJobRoot, 'blade_solid.step'), path.join(jobEvidenceRoot, 'blade_solid.step')),
  388 |     copyIfPresent(path.join(sourceJobRoot, 'progress.json'), path.join(jobEvidenceRoot, 'progress.json')),
  389 |     copyIfPresent(path.join(sourceJobRoot, 'build_stdout.log'), path.join(jobEvidenceRoot, 'build_stdout.log')),
  390 |     copyIfPresent(path.join(sourceJobRoot, 'build_stderr.log'), path.join(jobEvidenceRoot, 'build_stderr.log')),
  391 |   ])).filter((name): name is string => Boolean(name))
  392 | 
  393 |   let validation: JsonObject | undefined
  394 |   let artifactNames: string[] = []
  395 |   let artifactsApiOk = false
  396 |   let requiredArtifactsPresent = false
  397 |   let requiredArtifactDownloadsOk = false
  398 |   let submittedSpecMatchesExport = false
  399 |   let generatedSpecMatchesExport = false
  400 |   let resultIdentityVisible = false
  401 |   if (retained.includes('submitted_blade_spec.json')) {
  402 |     const submitted = JSON.parse(await readFile(path.join(jobEvidenceRoot, 'submitted_blade_spec.json'), 'utf8'))
  403 |     submittedSpecMatchesExport = isDeepStrictEqual(submitted, exportedCandidate)
  404 |   }
  405 |   if (retained.includes('blade_spec.json')) {
  406 |     const generatedSpec = JSON.parse(await readFile(path.join(jobEvidenceRoot, 'blade_spec.json'), 'utf8'))
  407 |     generatedSpecMatchesExport = isDeepStrictEqual(generatedSpec, exportedCandidate)
  408 |   }
  409 |   if (retained.includes('validation.json')) {
  410 |     validation = JSON.parse(await readFile(path.join(jobEvidenceRoot, 'validation.json'), 'utf8')) as JsonObject
  411 |   }
  412 |   if (terminalJob.status === 'succeeded') {
  413 |     const artifactsResponse = await page.request.get(`/api/jobs/${jobId}/artifacts`)
  414 |     artifactsApiOk = artifactsResponse.ok()
  415 |     const artifacts = artifactsApiOk
  416 |       ? await artifactsResponse.json() as Array<{ name: string; download_url: string }>
  417 |       : []
  418 |     artifactNames = artifacts.map(artifact => artifact.name)
  419 |     const requiredArtifactNames = ['blade_spec.json', 'validation.json', 'blade_solid.step', 'engine_manifest.json']
  420 |     requiredArtifactsPresent = requiredArtifactNames.every(name => artifactNames.includes(name))
  421 |     const downloadChecks: boolean[] = []
  422 |     for (const artifact of artifacts.filter(item => requiredArtifactNames.includes(item.name))) {
  423 |       const expectedUrl = `/api/jobs/${jobId}/artifacts/${artifact.name}`
  424 |       downloadChecks.push(
  425 |         artifact.download_url === expectedUrl
  426 |         && (await page.request.get(artifact.download_url)).ok(),
  427 |       )
  428 |     }
  429 |     requiredArtifactDownloadsOk = downloadChecks.length === requiredArtifactNames.length
  430 |       && downloadChecks.every(Boolean)
  431 |     resultIdentityVisible = await page.locator(`[data-result-job-id="${jobId}"]`)
  432 |       .waitFor({ state: 'visible', timeout: 30_000 })
  433 |       .then(() => true, () => false)
  434 |     if (resultIdentityVisible) {
  435 |       await page.screenshot({ path: path.join(evidenceRoot, 'x57_qualified_blade.png'), fullPage: true })
  436 |     }
  437 |   }
  438 | 
  439 |   const warmP95 = percentile(warmMs, 0.95)
  440 |   const latencyTargetMs = 1000
  441 |   const latencyPassed = warmP95 <= latencyTargetMs
  442 |   const applyMeasurements = [cold, ...warm]
  443 |   const applyRequestContractPassed = applyMeasurements.every(measurement => (
  444 |     measurement.request_counts.validate === 1
  445 |     && measurement.request_counts.preview === 1
  446 |     && measurement.request_counts.build === 0
  447 |   ))
  448 |   const undoRequestContractPassed = undoRequestCounts.every(counts => (
  449 |     counts.validate === 0 && counts.preview === 1 && counts.build === 0
  450 |   ))
  451 |   const solid = asObject(asObject(validation?.solidification)?.solid_after_reimport)
  452 |   const topologyPassed = solid?.solids === 1
  453 |     && solid.closed_shell === true
  454 |     && solid.brepcheck_valid === true
  455 |     && solid.free_edges === 0
  456 |   const internalValidationPassed = validation?.status === 'PASS'
  457 |     && topologyPassed
  458 |     && asObject(validation.geometry_validation)?.passed === true
  459 |     && asObject(validation.geometry_validation)?.station_count === 41
  460 |     && asArray(asObject(validation.geometry_validation)?.stations).length === 41
  461 |   const repositoryRoot = path.resolve('..')
  462 |   const baseCommit = execFileSync('git', ['rev-parse', 'HEAD'], {
  463 |     cwd: repositoryRoot,
  464 |     encoding: 'utf8',
  465 |   }).trim()
  466 |   const workingTreeStatus = execFileSync('git', ['status', '--short'], {
  467 |     cwd: repositoryRoot,
  468 |     encoding: 'utf8',
  469 |   }).trimEnd()
> 470 |   const trackedPatch = execFileSync('git', ['diff', '--binary', 'HEAD', '--'], {
      |                        ^ Error: spawnSync git ENOBUFS
  471 |     cwd: repositoryRoot,
  472 |     encoding: 'utf8',
  473 |     maxBuffer: 20 * 1024 * 1024,
  474 |   })
  475 |   const summary = {
  476 |     evidence_schema: 'bladegen.fp02.u2-evidence.v1',
  477 |     evidence_run_id: fp02RunId,
  478 |     tested_source_identity: {
  479 |       base_commit: baseCommit,
  480 |       worktree_clean: workingTreeStatus.length === 0,
  481 |       git_status_porcelain: workingTreeStatus,
  482 |       tracked_patch_sha256: createHash('sha256').update(trackedPatch).digest('hex'),
  483 |       x57_test_source_sha256: await sha256(path.resolve('e2e/sprint04b-x57.spec.ts')),
  484 |       x57_evidence_helper_sha256: await sha256(path.resolve('e2e/x57Evidence.ts')),
  485 |     },
  486 |     generated_at_utc: new Date().toISOString(),
  487 |     workflow: {
  488 |       input_method: 'real UI controls and supplied CSV file inputs',
  489 |       prepared_bladespec_injected: false,
  490 |       explicit_generate_count: buildRequests,
  491 |     },
  492 |     apply_to_current_preview_latency_ms: {
  493 |       definition: 'Actual browser Apply Once click event through matching successful /api/validate and /api/design-preview responses and current-preview UI state',
  494 |       target_ms: latencyTargetMs,
  495 |       acceptance_criterion: 'warm p95 <= target_ms',
  496 |       passed: latencyPassed,
  497 |       cold,
  498 |       warm_repetitions: warmMs.length,
  499 |       warm_operations: warm,
  500 |       warm_median: percentile(warmMs, 0.5),
  501 |       warm_p95: warmP95,
  502 |       warm_max: Math.max(...warmMs),
  503 |       apply_request_contract: {
  504 |         expected_per_operation: { validate: 1, preview: 1, build: 0 },
  505 |         passed: applyRequestContractPassed,
  506 |       },
  507 |       undo_cycles: {
  508 |         count: undoRequestCounts.length,
  509 |         request_counts: undoRequestCounts,
  510 |         expected_per_operation: { validate: 0, preview: 1, build: 0 },
  511 |         passed: undoRequestContractPassed,
  512 |       },
  513 |     },
  514 |     input_fidelity: inputFidelity,
  515 |     thickness_representation: {
  516 |       source_ratio: 0.1305067267946498,
  517 |       product_coordinate_measurement_ratio: 0.1305533776828919,
  518 |       ratio_delta: 0.000046650888242100175,
  519 |       percentage_point_delta: 0.0046650888242100175,
  520 |       status: 'DOCUMENTED_REPRESENTATION_DIFFERENCE',
  521 |     },
  522 |     generation: {
  523 |       job_id: jobId,
  524 |       status: terminalJob.status,
  525 |       stage: terminalJob.stage,
  526 |       error: terminalJob.error ?? null,
  527 |       elapsed_seconds: terminalJob.elapsed_seconds,
  528 |       api_artifacts: artifactNames,
  529 |       artifacts_api_ok: artifactsApiOk,
  530 |       required_artifacts_present: requiredArtifactsPresent,
  531 |       required_artifact_downloads_ok: requiredArtifactDownloadsOk,
  532 |       retained_files: retained,
  533 |       submitted_spec_matches_exported_candidate: submittedSpecMatchesExport,
  534 |       generated_blade_spec_matches_exported_candidate: generatedSpecMatchesExport,
  535 |       exact_result_identity_visible: resultIdentityVisible,
  536 |       submitted_spec_sha256: retained.includes('submitted_blade_spec.json')
  537 |         ? await sha256(path.join(jobEvidenceRoot, 'submitted_blade_spec.json'))
  538 |         : null,
  539 |       step_sha256: retained.includes('blade_solid.step')
  540 |         ? await sha256(path.join(jobEvidenceRoot, 'blade_solid.step'))
  541 |         : null,
  542 |       internal_validation: validation ?? null,
  543 |     },
  544 |     external_nasa_geometry_fidelity: {
  545 |       status: 'UNVERIFIED',
  546 |       reason: 'The supplied fixture bundle contains source-derived inputs and a recorded official-model URL/hash, but no official NASA VSP3/STEP geometry for an external surface comparison.',
  547 |     },
  548 |   }
  549 |   await writeFile(path.join(evidenceRoot, 'evidence_summary.json'), `${JSON.stringify(summary, null, 2)}\n`, 'utf8')
  550 | 
  551 |   expect(latencyPassed, `Warm Apply-to-current-preview p95 ${warmP95} ms exceeded ${latencyTargetMs} ms`).toBe(true)
  552 |   expect(applyRequestContractPassed, 'Each Apply must issue exactly one validation, one preview, and zero builds').toBe(true)
  553 |   expect(undoRequestContractPassed, 'Each Undo must issue one preview and no validation/build request').toBe(true)
  554 |   expect(
  555 |     terminalJob.status,
  556 |     `X-57 CAD job ${jobId} genuinely failed; retained evidence: ${JSON.stringify({ stage: terminalJob.stage, error: terminalJob.error, retained })}`,
  557 |   ).toBe('succeeded')
  558 |   expect(artifactsApiOk).toBe(true)
  559 |   expect(requiredArtifactsPresent).toBe(true)
  560 |   expect(requiredArtifactDownloadsOk).toBe(true)
  561 |   expect(submittedSpecMatchesExport).toBe(true)
  562 |   expect(generatedSpecMatchesExport).toBe(true)
  563 |   expect(internalValidationPassed).toBe(true)
  564 |   expect(resultIdentityVisible).toBe(true)
  565 | })
  566 | 
```